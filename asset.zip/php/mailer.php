<?php
/**
 * PADMA RMS — Mail wrapper (PHPMailer)
 * Requires: /php/phpmailer/ (PHPMailer 6.9 manual install)
 *   phpmailer/src/PHPMailer.php
 *   phpmailer/src/SMTP.php
 *   phpmailer/src/Exception.php
 */
if (!defined('CONFIG_GUARD')) { http_response_code(403); exit('Forbidden'); }

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception as PHPMailerException;

function phpmailer_loaded() {
    $base = __DIR__ . '/phpmailer/src/';
    if (!file_exists($base . 'PHPMailer.php')) return false;
    require_once $base . 'Exception.php';
    require_once $base . 'PHPMailer.php';
    require_once $base . 'SMTP.php';
    return true;
}

/**
 * Send a mail. Returns true on success.
 */
function send_mail($toEmail, $toName, $subject, $htmlBody) {
    if (!phpmailer_loaded()) {
        error_log('PHPMailer not installed in /php/phpmailer/src/');
        mail_log($toEmail, $subject, 'failed', 'PHPMailer not installed');
        return false;
    }
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = SMTP_HOST;
        $mail->SMTPAuth   = true;
        $mail->Username   = SMTP_USER;
        $mail->Password   = SMTP_PASS;
        $mail->SMTPSecure = SMTP_SECURE === 'ssl'
            ? PHPMailer::ENCRYPTION_SMTPS
            : PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = (int)SMTP_PORT;
        $mail->CharSet    = 'UTF-8';

        $mail->setFrom(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addReplyTo(MAIL_FROM, MAIL_FROM_NAME);
        $mail->addAddress($toEmail, $toName ?: $toEmail);
        $mail->isHTML(true);
        $mail->Subject = $subject;
        $mail->Body    = $htmlBody;
        $mail->AltBody = strip_tags(str_replace(['<br>', '<br/>', '</p>'], "\n", $htmlBody));

        $mail->send();
        mail_log($toEmail, $subject, 'sent', null);
        return true;
    } catch (PHPMailerException $e) {
        error_log('Mail send failed: ' . $mail->ErrorInfo);
        mail_log($toEmail, $subject, 'failed', $mail->ErrorInfo);
        return false;
    }
}

function mail_log($to, $subject, $status, $error) {
    try {
        DB::insert('email_log', [
            'recipient'  => $to,
            'subject'    => $subject,
            'status'     => $status,
            'error'      => $error,
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    } catch (Throwable $e) { error_log('mail_log insert failed: ' . $e->getMessage()); }
}

/* ------------------------------------------------------------
 * HTML EMAIL TEMPLATE
 * ------------------------------------------------------------ */
function mail_layout($title, $bodyHtml) {
    $brand = htmlspecialchars(APP_NAME, ENT_QUOTES, 'UTF-8');
    $url   = htmlspecialchars(APP_URL, ENT_QUOTES, 'UTF-8');
    return <<<HTML
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><title>{$title}</title></head>
<body style="margin:0;padding:0;background:#f6f7fb;font-family:-apple-system,'Segoe UI',system-ui,sans-serif;color:#111827;">
  <table width="100%" cellpadding="0" cellspacing="0" style="background:#f6f7fb;padding:32px 16px;">
    <tr><td align="center">
      <table width="100%" cellpadding="0" cellspacing="0" style="max-width:560px;background:#ffffff;border:1px solid #e5e8ee;border-radius:14px;overflow:hidden;">
        <tr><td style="padding:24px 28px;border-bottom:1px solid #e5e8ee;background:#eef2ff;">
          <div style="font-size:17px;font-weight:800;letter-spacing:-.2px;color:#4f46e5;">{$brand}</div>
          <div style="font-size:11px;color:#6b7280;text-transform:uppercase;letter-spacing:1px;margin-top:2px;">Retail Management System</div>
        </td></tr>
        <tr><td style="padding:28px;">
          <h1 style="font-size:20px;font-weight:700;margin:0 0 14px;">{$title}</h1>
          {$bodyHtml}
          <hr style="border:none;border-top:1px solid #e5e8ee;margin:24px 0 12px;">
          <div style="font-size:11px;color:#9ca3af;">
            This is an automated message from {$brand}. Please do not reply.<br>
            Need help? Contact us at <a href="mailto:admin@cosmonika.com" style="color:#4f46e5;text-decoration:none;">admin@cosmonika.com</a>.
          </div>
        </td></tr>
        <tr><td style="padding:14px 28px;background:#f3f5f9;font-size:11px;color:#6b7280;text-align:center;">
          &copy; {$brand} &middot; <a href="{$url}" style="color:#6b7280;text-decoration:none;">{$url}</a>
        </td></tr>
      </table>
    </td></tr>
  </table>
</body></html>
HTML;
}

/* ------------------------------------------------------------
 * TEMPLATES
 * ------------------------------------------------------------ */
function mail_verify_shop($shop, $verifyUrl) {
    $name = htmlspecialchars($shop['owner_name'] ?: 'there', ENT_QUOTES, 'UTF-8');
    $shopName = htmlspecialchars($shop['shop_name'], ENT_QUOTES, 'UTF-8');
    $shopId = htmlspecialchars($shop['shop_id'], ENT_QUOTES, 'UTF-8');
    $link = htmlspecialchars($verifyUrl, ENT_QUOTES, 'UTF-8');
    $body = <<<HTML
<p style="font-size:14px;line-height:1.6;margin:0 0 14px;">Hello {$name},</p>
<p style="font-size:14px;line-height:1.6;margin:0 0 14px;">
  A PADMA RMS account has been created for your shop <b>{$shopName}</b>.<br>
  Your Shop ID is: <b style="color:#4f46e5;letter-spacing:1px;">{$shopId}</b>.
</p>
<p style="font-size:14px;line-height:1.6;margin:0 0 20px;">Click the button below to verify your email and activate the account. The link expires in 48 hours.</p>
<p style="text-align:center;margin:24px 0;">
  <a href="{$link}" style="display:inline-block;background:#6366f1;color:#fff;padding:12px 22px;border-radius:10px;font-weight:700;text-decoration:none;font-size:14px;">Verify My Account</a>
</p>
<p style="font-size:12px;color:#6b7280;line-height:1.6;margin:0;">
  If the button does not work, copy and paste this link in your browser:<br>
  <span style="word-break:break-all;color:#4f46e5;">{$link}</span>
</p>
HTML;
    return mail_layout('Verify your PADMA RMS account', $body);
}

function mail_welcome_shop($shop) {
    $name = htmlspecialchars($shop['owner_name'] ?: 'there', ENT_QUOTES, 'UTF-8');
    $shopId = htmlspecialchars($shop['shop_id'], ENT_QUOTES, 'UTF-8');
    $email  = htmlspecialchars($shop['email'], ENT_QUOTES, 'UTF-8');
    $loginUrl = htmlspecialchars(APP_URL, ENT_QUOTES, 'UTF-8');
    $body = <<<HTML
<p style="font-size:14px;line-height:1.6;margin:0 0 14px;">Hello {$name},</p>
<p style="font-size:14px;line-height:1.6;margin:0 0 14px;">
  Your account is now ready. You can log in to PADMA RMS using the details below.
</p>
<table cellpadding="0" cellspacing="0" style="margin:18px 0;background:#f3f5f9;border-radius:10px;padding:14px 18px;width:100%;">
  <tr><td style="font-size:13px;color:#6b7280;padding:4px 0;">Shop ID</td><td style="font-size:13px;font-weight:700;text-align:right;">{$shopId}</td></tr>
  <tr><td style="font-size:13px;color:#6b7280;padding:4px 0;">Email</td><td style="font-size:13px;font-weight:700;text-align:right;">{$email}</td></tr>
</table>
<p style="text-align:center;margin:24px 0;">
  <a href="{$loginUrl}" style="display:inline-block;background:#6366f1;color:#fff;padding:12px 22px;border-radius:10px;font-weight:700;text-decoration:none;font-size:14px;">Log in to PADMA RMS</a>
</p>
<p style="font-size:12px;color:#6b7280;line-height:1.6;margin:0;">
  If you did not request this, please contact us immediately at admin@cosmonika.com.
</p>
HTML;
    return mail_layout('Your PADMA RMS account is ready', $body);
}

function mail_reset_password($shop, $resetUrl) {
    $name = htmlspecialchars($shop['owner_name'] ?: 'there', ENT_QUOTES, 'UTF-8');
    $link = htmlspecialchars($resetUrl, ENT_QUOTES, 'UTF-8');
    $body = <<<HTML
<p style="font-size:14px;line-height:1.6;margin:0 0 14px;">Hello {$name},</p>
<p style="font-size:14px;line-height:1.6;margin:0 0 14px;">
  We received a request to reset the password for your PADMA RMS account.<br>
  Click the button below to set a new password. This link expires in 2 hours.
</p>
<p style="text-align:center;margin:24px 0;">
  <a href="{$link}" style="display:inline-block;background:#6366f1;color:#fff;padding:12px 22px;border-radius:10px;font-weight:700;text-decoration:none;font-size:14px;">Reset Password</a>
</p>
<p style="font-size:12px;color:#6b7280;line-height:1.6;margin:0;">
  If you did not request a reset, you can safely ignore this email.
</p>
HTML;
    return mail_layout('Reset your PADMA RMS password', $body);
}