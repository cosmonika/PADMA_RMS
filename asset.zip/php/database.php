<?php
/**
 * PADMA RMS — Database connection (PDO singleton)
 */
if (!defined('CONFIG_GUARD')) { http_response_code(403); exit('Forbidden'); }

class DB {
    private static $instance = null;
    private $pdo;

    private function __construct() {
        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
        $opts = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_STRINGIFY_FETCHES  => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET time_zone = '+05:30'",
        ];
        try {
            $this->pdo = new PDO($dsn, DB_USER, DB_PASS, $opts);
        } catch (PDOException $e) {
            error_log('DB connect failed: ' . $e->getMessage());
            http_response_code(500);
            exit('Database connection failed. Please contact administrator.');
        }
    }

    public static function pdo() {
        if (self::$instance === null) { self::$instance = new self(); }
        return self::$instance->pdo;
    }

    /* Helpers -------------------------------------------------- */

    public static function run($sql, $params = []) {
        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt;
    }

    public static function one($sql, $params = []) {
        return self::run($sql, $params)->fetch();
    }

    public static function all($sql, $params = []) {
        return self::run($sql, $params)->fetchAll();
    }

    public static function col($sql, $params = []) {
        return self::run($sql, $params)->fetchColumn();
    }

    public static function insert($table, $data) {
        $cols = array_keys($data);
        $place = array_map(fn($c) => ':' . $c, $cols);
        $sql = "INSERT INTO `$table` (`" . implode('`,`', $cols) . "`) VALUES (" . implode(',', $place) . ")";
        $stmt = self::pdo()->prepare($sql);
        foreach ($data as $k => $v) { $stmt->bindValue(':' . $k, $v); }
        $stmt->execute();
        return self::pdo()->lastInsertId();
    }

    public static function update($table, $data, $where, $whereParams = []) {
        $sets = [];
        foreach (array_keys($data) as $c) { $sets[] = "`$c` = :$c"; }
        $sql = "UPDATE `$table` SET " . implode(',', $sets) . " WHERE $where";
        $stmt = self::pdo()->prepare($sql);
        foreach ($data as $k => $v) { $stmt->bindValue(':' . $k, $v); }
        foreach ($whereParams as $k => $v) { $stmt->bindValue(':' . $k, $v); }
        $stmt->execute();
        return $stmt->rowCount();
    }

    public static function delete($table, $where, $params = []) {
        return self::run("DELETE FROM `$table` WHERE $where", $params)->rowCount();
    }

    public static function begin() { self::pdo()->beginTransaction(); }
    public static function commit() { self::pdo()->commit(); }
    public static function rollback() { if (self::pdo()->inTransaction()) self::pdo()->rollBack(); }
}