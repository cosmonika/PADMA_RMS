<?php
/**
 * PADMA RMS — System Admin Panel
 * URL: https://padma.cosmonika.com/php/system_admin.php
 * (Optionally alias to /admin.php at root — see deployment notes.)
 */
define('CONFIG_GUARD', 1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/mailer.php';

admin_session_start();

/* ============================================================
 * ACTIONS
 * ============================================================ */
$action = $_POST['action'] ?? $_GET['action'] ?? '';
$flash  = ['type' => '', 'msg' => ''];

if ($action === 'login' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) {
        $flash = ['type' => 'err', 'msg' => 'Security token mismatch. Please try again.'];
    } elseif (admin_login($_POST['email'] ?? '', $_POST['password'] ?? '')) {
        audit(null, ADMIN_EMAIL, 'admin_login', ['ip' => client_ip()]);
        header('Location: system_admin.php'); exit;
    } else {
        audit(null, $_POST['email'] ?? '', 'admin_login_failed', ['ip' => client_ip()]);
        $flash = ['type' => 'err', 'msg' => 'Invalid email or password.'];
    }
}

if ($action === 'logout') {
    audit(null, $_SESSION['admin_email'] ?? '', 'admin_logout', []);
    admin_logout();
    header('Location: system_admin.php'); exit;
}

if (!admin_is_logged_in() && $action !== 'login') {
    render_login($flash); exit;
}

/* ---- Create Shop ---- */
if ($action === 'create_shop' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) {
        $flash = ['type' => 'err', 'msg' => 'Security token mismatch.'];
    } else {
        $result = admin_create_shop($_POST);
        if ($result['ok']) {
            $flash = ['type' => 'ok', 'msg' => 'Shop created (' . $result['shop_id'] . '). Verification email sent to ' . $result['email'] . '.'];
        } else {
            $flash = ['type' => 'err', 'msg' => $result['error']];
        }
    }
}

/* ---- Resend Verification ---- */
if ($action === 'resend_verify' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { $flash = ['type'=>'err','msg'=>'CSRF']; }
    else {
        $id = (int)($_POST['shop_ref'] ?? 0);
        $r = admin_resend_verify($id);
        $flash = ['type' => $r['ok'] ? 'ok' : 'err', 'msg' => $r['msg']];
    }
}

/* ---- Suspend / Activate ---- */
if (in_array($action, ['suspend_shop','activate_shop'], true) && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { $flash = ['type'=>'err','msg'=>'CSRF']; }
    else {
        $id = (int)($_POST['shop_ref'] ?? 0);
        $newStatus = $action === 'suspend_shop' ? 'suspended' : 'active';
        try {
            DB::update('shops', ['status'=>$newStatus,'updated_at'=>date('Y-m-d H:i:s')], 'id = :id', ['id'=>$id]);
            audit($id, $_SESSION['admin_email'], 'admin_' . $action, []);
            $flash = ['type'=>'ok','msg'=>'Shop status updated.'];
        } catch (Throwable $e) {
            $flash = ['type'=>'err','msg'=>'Update failed.'];
        }
    }
}

/* ---- Delete (soft) ---- */
if ($action === 'delete_shop' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_check($_POST['csrf'] ?? '')) { $flash = ['type'=>'err','msg'=>'CSRF']; }
    else {
        $id = (int)($_POST['shop_ref'] ?? 0);
        try {
            DB::update('shops', ['status'=>'deleted','updated_at'=>date('Y-m-d H:i:s')], 'id = :id', ['id'=>$id]);
            audit($id, $_SESSION['admin_email'], 'admin_delete_shop', []);
            $flash = ['type'=>'ok','msg'=>'Shop moved to deleted.'];
        } catch (Throwable $e) {
            $flash = ['type'=>'err','msg'=>'Delete failed.'];
        }
    }
}

/* ============================================================
 * FUNCTIONS
 * ============================================================ */
function admin_create_shop($d) {
    $shopName  = trim((string)($d['shop_name']   ?? ''));
    $ownerName = trim((string)($d['owner_name']  ?? ''));
    $email     = strtolower(trim((string)($d['email'] ?? '')));
    $mobile    = preg_replace('/\D/', '', (string)($d['mobile'] ?? ''));
    $gstin     = trim((string)($d['gstin']    ?? ''));
    $address   = trim((string)($d['address']  ?? ''));
    $city      = trim((string)($d['city']     ?? ''));
    $state     = trim((string)($d['state']    ?? ''));
    $pincode   = trim((string)($d['pincode']  ?? ''));
    $country   = trim((string)($d['country']  ?? 'India')) ?: 'India';
    $license   = trim((string)($d['license_expires_at'] ?? ''));
    $currency  = trim((string)($d['currency'] ?? 'INR')) ?: 'INR';
    $symbol    = trim((string)($d['currency_symbol'] ?? '₹')) ?: '₹';

    if ($shopName === '')  return ['ok'=>false,'error'=>'Shop name is required.'];
    if ($ownerName === '') return ['ok'=>false,'error'=>'Owner name is required.'];
    if (!valid_email($email)) return ['ok'=>false,'error'=>'Valid email required.'];
    if (!valid_mobile($mobile)) return ['ok'=>false,'error'=>'Valid mobile required.'];

    if (DB::col("SELECT 1 FROM shops WHERE email = ?", [$email]))  return ['ok'=>false,'error'=>'This email is already registered.'];
    if (DB::col("SELECT 1 FROM shops WHERE mobile = ?", [$mobile])) return ['ok'=>false,'error'=>'This mobile is already registered.'];

    $shop_id = generate_shop_id();
    $now = date('Y-m-d H:i:s');

    $settings = shops_default_settings();

    DB::begin();
    try {
        DB::insert('shops', [
            'shop_id'           => $shop_id,
            'shop_name'         => $shopName,
            'owner_name'        => $ownerName,
            'email'             => $email,
            'mobile'            => $mobile,
            'password_hash'     => null,
            'gstin'             => $gstin ?: null,
            'address'           => $address ?: null,
            'city'              => $city ?: null,
            'state'             => $state ?: null,
            'pincode'           => $pincode ?: null,
            'country'           => $country,
            'currency'          => $currency,
            'currency_symbol'   => $symbol,
            'invoice_prefix'    => 'INV',
            'invoice_next'      => 1,
            'status'            => 'pending',
            'license_expires_at'=> $license ? date('Y-m-d H:i:s', strtotime($license)) : null,
            'onboarding_done'   => 0,
            'settings_json'     => json_encode($settings, JSON_UNESCAPED_UNICODE),
            'created_at'        => $now,
            'updated_at'        => $now,
        ]);
        $shopRowId = (int)DB::col("SELECT id FROM shops WHERE shop_id = ?", [$shop_id]);

        $token = generate_token(48);
        DB::insert('email_verifications', [
            'shop_ref'   => $shopRowId,
            'token'      => $token,
            'purpose'    => 'verify_email',
            'expires_at' => date('Y-m-d H:i:s', time() + VERIFY_TTL_HOURS * 3600),
            'used'       => 0,
            'created_at' => $now,
        ]);
        DB::commit();
    } catch (Throwable $e) {
        DB::rollback();
        error_log('create_shop failed: ' . $e->getMessage());
        return ['ok'=>false,'error'=>'Could not create shop. Check server logs.'];
    }

    $verifyUrl = APP_URL . '/php/verify.php?token=' . $token;
    $html = mail_verify_shop([
        'owner_name'=>$ownerName,'shop_name'=>$shopName,'shop_id'=>$shop_id,'email'=>$email,
    ], $verifyUrl);

    $sent = send_mail($email, $ownerName, 'Verify your PADMA RMS account', $html);

    audit($shopRowId, $_SESSION['admin_email'], 'admin_create_shop', ['shop_id'=>$shop_id]);
    if (!$sent) {
        return ['ok'=>true,'shop_id'=>$shop_id,'email'=>$email,
            'warning'=>'Shop created but verification email could not be sent. Use "Resend" to try again.'];
    }
    return ['ok'=>true,'shop_id'=>$shop_id,'email'=>$email];
}

function admin_resend_verify($id) {
    $shop = DB::one("SELECT * FROM shops WHERE id = ?", [$id]);
    if (!$shop) return ['ok'=>false,'msg'=>'Shop not found.'];
    if ($shop['email_verified_at']) return ['ok'=>false,'msg'=>'This shop is already verified.'];

    // invalidate old tokens for this shop
    DB::run("UPDATE email_verifications SET used = 1 WHERE shop_ref = ? AND purpose = 'verify_email' AND used = 0", [$id]);

    $token = generate_token(48);
    DB::insert('email_verifications', [
        'shop_ref'   => $id,
        'token'      => $token,
        'purpose'    => 'verify_email',
        'expires_at' => date('Y-m-d H:i:s', time() + VERIFY_TTL_HOURS * 3600),
        'used'       => 0,
        'created_at' => date('Y-m-d H:i:s'),
    ]);
    $url = APP_URL . '/php/verify.php?token=' . $token;
    $html = mail_verify_shop($shop, $url);
    $sent = send_mail($shop['email'], $shop['owner_name'], 'Verify your PADMA RMS account', $html);
    audit($id, $_SESSION['admin_email'], 'admin_resend_verify', []);
    return $sent ? ['ok'=>true,'msg'=>'Verification email resent.'] : ['ok'=>false,'msg'=>'Email send failed. Check mail config.'];
}

/* ============================================================
 * RENDER
 * ============================================================ */
function render_login($flash) {
    $app   = h(APP_NAME);
    $err   = $flash['msg'] ? '<div class="err">' . h($flash['msg']) . '</div>' : '';
    $csrf  = csrf_token();
    echo <<<HTML
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin Login — {$app}</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,'Segoe UI',system-ui,sans-serif;background:#f6f7fb;color:#111827;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;font-size:14px}
  .card{max-width:400px;width:100%;background:#fff;border:1px solid #e5e8ee;border-radius:14px;box-shadow:0 20px 48px rgba(16,24,40,.08);overflow:hidden}
  .head{padding:22px 26px;background:#eef2ff;border-bottom:1px solid #e5e8ee}
  .brand{font-size:16px;font-weight:800;color:#4f46e5}
  .brand small{display:block;font-size:10px;color:#6b7280;font-weight:500;text-transform:uppercase;letter-spacing:1px;margin-top:2px}
  .body{padding:26px}
  h1{font-size:18px;font-weight:700;margin-bottom:16px}
  .field{display:flex;flex-direction:column;gap:5px;margin-bottom:14px}
  .field label{font-size:12px;font-weight:600;color:#4b5563}
  .field input{height:38px;padding:0 12px;border:1px solid #e5e8ee;border-radius:8px;font-size:14px;outline:none;color:#111827;background:#fff}
  .field input:focus{border-color:#6366f1;box-shadow:0 0 0 3px #eef2ff}
  .btn{background:#6366f1;color:#fff;padding:11px 20px;border-radius:9px;font-weight:700;font-size:13px;border:none;cursor:pointer;width:100%}
  .btn:hover{background:#4f46e5}
  .err{background:#fee2e2;color:#ef4444;padding:10px 12px;border-radius:8px;font-size:12.5px;margin-bottom:14px}
</style></head><body>
  <div class="card">
    <div class="head"><div class="brand">{$app}<small>System Admin</small></div></div>
    <div class="body">
      <h1>Administrator login</h1>
      {$err}
      <form method="post">
        <input type="hidden" name="action" value="login">
        <input type="hidden" name="csrf" value="{$csrf}">
        <div class="field"><label>Email</label><input type="email" name="email" required autofocus autocomplete="username"></div>
        <div class="field"><label>Password</label><input type="password" name="password" required autocomplete="current-password"></div>
        <button type="submit" class="btn">Sign in</button>
      </form>
    </div>
  </div>
</body></html>
HTML;
}

/* ---- Dashboard ---- */
$shops = DB::all("SELECT * FROM shops WHERE status <> 'deleted' ORDER BY id DESC");
$stats = [
    'total'     => (int)DB::col("SELECT COUNT(*) FROM shops WHERE status <> 'deleted'"),
    'pending'   => (int)DB::col("SELECT COUNT(*) FROM shops WHERE status = 'pending'"),
    'active'    => (int)DB::col("SELECT COUNT(*) FROM shops WHERE status = 'active'"),
    'suspended' => (int)DB::col("SELECT COUNT(*) FROM shops WHERE status = 'suspended'"),
];

$flashHtml = '';
if ($flash['msg']) {
    $cls = $flash['type'] === 'ok' ? 'ok' : 'err';
    $flashHtml = '<div class="flash ' . $cls . '">' . h($flash['msg']) . '</div>';
}

$app  = h(APP_NAME);
$email = h($_SESSION['admin_email'] ?? '');
$csrf = csrf_token();

$rowsHtml = '';
if (!$shops) {
    $rowsHtml = '<tr><td colspan="8" style="text-align:center;color:#9ca3af;padding:32px">No shops yet. Click "Create Shop" to start.</td></tr>';
} else {
    foreach ($shops as $s) {
        $badgeCls = 'b-' . ($s['status'] === 'active' ? 'ok' : ($s['status'] === 'pending' ? 'warn' : ($s['status'] === 'suspended' ? 'err' : 'muted')));
        $lic = $s['license_expires_at'] ? h(date('d M Y', strtotime($s['license_expires_at']))) : '—';
        $created = h(date('d M Y', strtotime($s['created_at'])));
        $actions = '';
        if ($s['status'] === 'pending' && !$s['email_verified_at']) {
            $actions .= '<form method="post" style="display:inline"><input type="hidden" name="action" value="resend_verify"><input type="hidden" name="csrf" value="'.$csrf.'"><input type="hidden" name="shop_ref" value="'.$s['id'].'"><button class="btn-xs" type="submit">Resend</button></form> ';
        }
        if ($s['status'] === 'active') {
            $actions .= '<form method="post" style="display:inline"><input type="hidden" name="action" value="suspend_shop"><input type="hidden" name="csrf" value="'.$csrf.'"><input type="hidden" name="shop_ref" value="'.$s['id'].'"><button class="btn-xs" type="submit">Suspend</button></form> ';
        }
        if ($s['status'] === 'suspended') {
            $actions .= '<form method="post" style="display:inline"><input type="hidden" name="action" value="activate_shop"><input type="hidden" name="csrf" value="'.$csrf.'"><input type="hidden" name="shop_ref" value="'.$s['id'].'"><button class="btn-xs" type="submit">Activate</button></form> ';
        }
        $actions .= '<form method="post" style="display:inline" onsubmit="return confirm(\'Mark shop as deleted? This hides the shop but preserves data.\');"><input type="hidden" name="action" value="delete_shop"><input type="hidden" name="csrf" value="'.$csrf.'"><input type="hidden" name="shop_ref" value="'.$s['id'].'"><button class="btn-xs btn-xs-danger" type="submit">Delete</button></form>';
        $pwdSet = $s['password_hash'] ? '<span class="dot ok"></span> Set' : '<span class="dot warn"></span> Not set';
        $rowsHtml .= '<tr>'
          . '<td><code>'.h($s['shop_id']).'</code></td>'
          . '<td><b>'.h($s['shop_name']).'</b><br><small style="color:#9ca3af">'.h($s['owner_name']).'</small></td>'
          . '<td>'.h($s['email']).'<br><small style="color:#9ca3af">'.h($s['mobile']).'</small></td>'
          . '<td><span class="badge '.$badgeCls.'">'.h(ucfirst($s['status'])).'</span></td>'
          . '<td>'.$pwdSet.'</td>'
          . '<td>'.$lic.'</td>'
          . '<td>'.$created.'</td>'
          . '<td>'.$actions.'</td>'
          . '</tr>';
    }
}

echo <<<HTML
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Admin — {$app}</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,'Segoe UI',system-ui,sans-serif;background:#f6f7fb;color:#111827;font-size:14px;line-height:1.5}
  .topbar{background:#fff;border-bottom:1px solid #e5e8ee;padding:14px 24px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:10}
  .brand{font-size:16px;font-weight:800;color:#4f46e5}
  .brand small{display:block;font-size:10px;color:#6b7280;font-weight:500;text-transform:uppercase;letter-spacing:1px;margin-top:2px}
  .who{font-size:12.5px;color:#6b7280;display:flex;align-items:center;gap:12px}
  .who a{color:#4f46e5;text-decoration:none;font-weight:600}
  .wrap{max-width:1200px;margin:0 auto;padding:24px}
  .flash{padding:12px 16px;border-radius:10px;font-size:13px;margin-bottom:16px;font-weight:500}
  .flash.ok{background:#d1fae5;color:#059669}
  .flash.err{background:#fee2e2;color:#ef4444}
  .kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(180px,1fr));gap:14px;margin-bottom:20px}
  .kpi{background:#fff;border:1px solid #e5e8ee;border-radius:12px;padding:14px}
  .kpi .lb{font-size:11.5px;color:#6b7280;font-weight:600;text-transform:uppercase;letter-spacing:.5px;margin-bottom:4px}
  .kpi .vl{font-size:22px;font-weight:800;letter-spacing:-.5px}
  .card{background:#fff;border:1px solid #e5e8ee;border-radius:14px;overflow:hidden;margin-bottom:20px}
  .card-head{padding:14px 18px;border-bottom:1px solid #e5e8ee;display:flex;align-items:center;justify-content:space-between}
  .card-head h2{font-size:15px;font-weight:700}
  table{width:100%;border-collapse:collapse;font-size:13px}
  thead{background:#f3f5f9}
  th{text-align:left;padding:10px 14px;font-size:11px;text-transform:uppercase;letter-spacing:.5px;color:#6b7280;font-weight:600;border-bottom:1px solid #e5e8ee;white-space:nowrap}
  td{padding:12px 14px;border-bottom:1px solid #e5e8ee;vertical-align:middle}
  tbody tr:hover{background:#f9fafb}
  code{font-family:ui-monospace,'Courier New',monospace;background:#f3f5f9;padding:2px 6px;border-radius:4px;font-size:12px}
  .badge{display:inline-block;padding:3px 9px;border-radius:20px;font-size:11px;font-weight:700}
  .b-ok{background:#d1fae5;color:#059669}
  .b-warn{background:#fef3c7;color:#a16207}
  .b-err{background:#fee2e2;color:#ef4444}
  .b-muted{background:#f3f5f9;color:#6b7280}
  .btn{background:#6366f1;color:#fff;padding:9px 16px;border-radius:9px;font-weight:700;font-size:12.5px;border:none;cursor:pointer}
  .btn:hover{background:#4f46e5}
  .btn-xs{padding:5px 10px;border-radius:6px;font-size:11.5px;font-weight:600;border:1px solid #e5e8ee;background:#fff;color:#4b5563;cursor:pointer}
  .btn-xs:hover{background:#f3f5f9}
  .btn-xs-danger{color:#ef4444;border-color:#fecaca}
  .btn-xs-danger:hover{background:#fee2e2}
  .dot{display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:5px;vertical-align:middle}
  .dot.ok{background:#10b981}
  .dot.warn{background:#f59e0b}
  .modal-backdrop{position:fixed;inset:0;background:rgba(15,20,30,.55);z-index:1000;display:none;align-items:flex-start;justify-content:center;padding:40px 16px;overflow-y:auto}
  .modal-backdrop.open{display:flex}
  .modal{background:#fff;border-radius:14px;width:100%;max-width:620px;box-shadow:0 20px 48px rgba(16,24,40,.16);overflow:hidden}
  .modal-head{padding:16px 20px;border-bottom:1px solid #e5e8ee;display:flex;align-items:center;justify-content:space-between}
  .modal-head h3{font-size:16px;font-weight:700}
  .modal-head button{background:none;border:none;font-size:20px;cursor:pointer;color:#6b7280;line-height:1}
  .modal-body{padding:20px;max-height:70vh;overflow-y:auto}
  .modal-foot{padding:14px 20px;border-top:1px solid #e5e8ee;background:#f9fafb;display:flex;justify-content:flex-end;gap:8px}
  .grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:14px}
  .grid .full{grid-column:1/-1}
  .field{display:flex;flex-direction:column;gap:5px}
  .field label{font-size:12px;font-weight:600;color:#4b5563}
  .field label .req{color:#ef4444;font-style:normal}
  .field input,.field select,.field textarea{height:38px;padding:0 11px;border:1px solid #e5e8ee;border-radius:8px;font-size:13.5px;outline:none;background:#fff;color:#111827;font-family:inherit}
  .field textarea{height:auto;min-height:64px;padding:8px 11px;resize:vertical}
  .field input:focus,.field select:focus,.field textarea:focus{border-color:#6366f1;box-shadow:0 0 0 3px #eef2ff}
  .hint{font-size:11px;color:#9ca3af}
  @media (max-width:768px){
    .wrap{padding:16px}
    th,td{padding:8px 10px;font-size:12px}
    .topbar{padding:12px 16px}
    .who{font-size:11.5px}
  }
</style></head><body>
  <div class="topbar">
    <div class="brand">{$app}<small>System Admin</small></div>
    <div class="who">
      <span>Signed in as <b>{$email}</b></span>
      <form method="post" style="margin:0"><input type="hidden" name="action" value="logout"><button class="btn-xs" type="submit">Log out</button></form>
    </div>
  </div>

  <div class="wrap">
    {$flashHtml}

    <div class="kpis">
      <div class="kpi"><div class="lb">Total shops</div><div class="vl">{$stats['total']}</div></div>
      <div class="kpi"><div class="lb">Pending</div><div class="vl">{$stats['pending']}</div></div>
      <div class="kpi"><div class="lb">Active</div><div class="vl">{$stats['active']}</div></div>
      <div class="kpi"><div class="lb">Suspended</div><div class="vl">{$stats['suspended']}</div></div>
    </div>

    <div class="card">
      <div class="card-head">
        <h2>Shops</h2>
        <button class="btn" id="openCreate">Create Shop</button>
      </div>
      <div style="overflow-x:auto">
        <table>
          <thead><tr><th>Shop ID</th><th>Shop / Owner</th><th>Email / Mobile</th><th>Status</th><th>Password</th><th>License</th><th>Created</th><th>Actions</th></tr></thead>
          <tbody>{$rowsHtml}</tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Create Shop Modal -->
  <div class="modal-backdrop" id="createModal">
    <div class="modal">
      <form method="post">
        <input type="hidden" name="action" value="create_shop">
        <input type="hidden" name="csrf" value="{$csrf}">
        <div class="modal-head"><h3>Create Shop</h3><button type="button" id="closeCreate">&times;</button></div>
        <div class="modal-body">
          <div class="grid">
            <div class="field full"><label>Shop Name <em class="req">*</em></label><input name="shop_name" required maxlength="150" autofocus></div>
            <div class="field full"><label>Owner Name <em class="req">*</em></label><input name="owner_name" required maxlength="150"></div>
            <div class="field"><label>Email <em class="req">*</em></label><input name="email" type="email" required maxlength="150"><div class="hint">Verification mail goes here. Cannot be changed later.</div></div>
            <div class="field"><label>Mobile <em class="req">*</em></label><input name="mobile" required maxlength="20" placeholder="10-digit"><div class="hint">Cannot be changed later.</div></div>
            <div class="field"><label>GSTIN</label><input name="gstin" maxlength="30"></div>
            <div class="field"><label>License Expires</label><input name="license_expires_at" type="date"><div class="hint">Blank = no expiry</div></div>
            <div class="field full"><label>Address</label><textarea name="address"></textarea></div>
            <div class="field"><label>City</label><input name="city" maxlength="80"></div>
            <div class="field"><label>State</label><input name="state" maxlength="80"></div>
            <div class="field"><label>Pincode</label><input name="pincode" maxlength="10"></div>
            <div class="field"><label>Country</label><input name="country" value="India" maxlength="80"></div>
            <div class="field"><label>Currency</label><input name="currency" value="INR" maxlength="10"></div>
            <div class="field"><label>Currency Symbol</label><input name="currency_symbol" value="₹" maxlength="10"></div>
          </div>
        </div>
        <div class="modal-foot">
          <button type="button" class="btn-xs" id="cancelCreate">Cancel</button>
          <button type="submit" class="btn">Create &amp; Send Verification</button>
        </div>
      </form>
    </div>
  </div>

  <script>
    (function(){
      var m = document.getElementById('createModal');
      document.getElementById('openCreate').onclick = function(){ m.classList.add('open'); };
      document.getElementById('closeCreate').onclick = function(){ m.classList.remove('open'); };
      document.getElementById('cancelCreate').onclick = function(){ m.classList.remove('open'); };
      m.addEventListener('click', function(e){ if(e.target === m) m.classList.remove('open'); });
    })();
  </script>
</body></html>
HTML;