<?php
/**
 * PADMA RMS — Shared helper functions
 */
if (!defined('CONFIG_GUARD')) { http_response_code(403); exit('Forbidden'); }

/* ------------------------------------------------------------
 * RESPONSES
 * ------------------------------------------------------------ */
function json_ok($data = [], $code = 200) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => true, 'data' => $data], JSON_UNESCAPED_UNICODE);
    exit;
}

function json_err($message, $code = 400, $extra = []) {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(array_merge(['ok' => false, 'message' => $message], $extra), JSON_UNESCAPED_UNICODE);
    exit;
}

/* ------------------------------------------------------------
 * REQUEST
 * ------------------------------------------------------------ */
function client_ip() {
    if (!empty($_SERVER['HTTP_CF_CONNECTING_IP'])) return $_SERVER['HTTP_CF_CONNECTING_IP'];
    if (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $parts = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);
        return trim($parts[0]);
    }
    return $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
}

function user_agent() {
    return substr($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown', 0, 250);
}

function read_json_body() {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function request_data() {
    $ctype = $_SERVER['CONTENT_TYPE'] ?? '';
    if (stripos($ctype, 'application/json') !== false) {
        return read_json_body();
    }
    return array_merge($_GET, $_POST);
}

/* ------------------------------------------------------------
 * AUTH / SHOP CONTEXT
 * ------------------------------------------------------------ */
function bearer_token() {
    $hdr = $_SERVER['HTTP_AUTHORIZATION'] ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '';
    if (!$hdr && function_exists('apache_request_headers')) {
        $h = apache_request_headers();
        if (!empty($h['Authorization'])) $hdr = $h['Authorization'];
    }
    if (preg_match('/^Bearer\s+(.+)$/i', $hdr, $m)) return trim($m[1]);
    if (!empty($_SERVER['HTTP_X_AUTH_TOKEN'])) return $_SERVER['HTTP_X_AUTH_TOKEN'];
    return null;
}

function generate_token($bytes = 48) {
    return bin2hex(random_bytes($bytes));
}

function hash_token($token) {
    return hash('sha256', $token);
}

/**
 * Validates the Bearer token and returns the shop row, or exits with 401.
 */
function require_shop_auth() {
    $token = bearer_token();
    if (!$token) json_err('Authentication required', 401);

    $hash = hash_token($token);
    $row = DB::one(
        "SELECT s.* FROM sessions ss
         JOIN shops s ON s.id = ss.shop_ref
         WHERE ss.token_hash = ? AND ss.expires_at > NOW()
         LIMIT 1",
        [$hash]
    );
    if (!$row) json_err('Session expired or invalid', 401);
    if ($row['status'] !== 'active') json_err('Account is not active', 403);
    if ($row['license_expires_at'] && strtotime($row['license_expires_at']) < time()) {
        json_err('License expired', 403);
    }

    // update last_used_at (throttled: only if older than 5 min)
    DB::run(
        "UPDATE sessions SET last_used_at = NOW()
         WHERE token_hash = ? AND (last_used_at IS NULL OR last_used_at < DATE_SUB(NOW(), INTERVAL 5 MINUTE))",
        [$hash]
    );
    return $row;
}

/* ------------------------------------------------------------
 * SHOP HELPERS
 * ------------------------------------------------------------ */
function shops_default_settings() {
    return [
        'theme'              => 'light',
        'lowStockThreshold'  => 5,
        'allowNegativeStock' => false,
        'defaultTax'         => 0,
        'onboardingDone'     => false,
        'invoiceFooter'      => 'Thank you for shopping with us!',
    ];
}

function shop_settings($shop) {
    $defaults = shops_default_settings();
    if (!empty($shop['settings_json'])) {
        $custom = json_decode($shop['settings_json'], true);
        if (is_array($custom)) return array_merge($defaults, $custom);
    }
    return $defaults;
}

/**
 * Public shape of shop for client (no password_hash, no internal flags).
 */
function shop_public($shop) {
    return [
        'id'              => (int)$shop['id'],
        'shopId'          => $shop['shop_id'],
        'name'            => $shop['shop_name'],
        'ownerName'       => $shop['owner_name'],
        'email'           => $shop['email'],
        'phone'           => $shop['mobile'],
        'gstin'           => $shop['gstin'],
        'address'         => $shop['address'],
        'city'            => $shop['city'],
        'state'           => $shop['state'],
        'pincode'         => $shop['pincode'],
        'country'         => $shop['country'],
        'currency'        => $shop['currency'],
        'currencySymbol'  => $shop['currency_symbol'],
        'invoicePrefix'   => $shop['invoice_prefix'],
        'invoiceNext'     => (int)$shop['invoice_next'],
        'logo'            => $shop['logo_path'] ? (APP_URL . $shop['logo_path']) : null,
        'status'          => $shop['status'],
        'createdAt'       => $shop['created_at'],
    ];
}

function mask_email($email) {
    if (strpos($email, '@') === false) return $email;
    [$local, $domain] = explode('@', $email, 2);
    $shown = substr($local, 0, 1);
    return $shown . str_repeat('*', max(1, strlen($local) - 1)) . '@' . $domain;
}

function mask_mobile($mobile) {
    $len = strlen($mobile);
    if ($len < 4) return $mobile;
    return substr($mobile, 0, 2) . str_repeat('*', $len - 4) . substr($mobile, -2);
}

/* ------------------------------------------------------------
 * VALIDATION
 * ------------------------------------------------------------ */
function valid_email($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL) !== false && strlen($email) <= 150;
}

function valid_mobile($mobile) {
    return preg_match('/^[0-9]{7,15}$/', preg_replace('/\D/', '', $mobile)) === 1;
}

function valid_shop_id($sid) {
    return preg_match('/^PAD-[0-9]{6}$/', $sid) === 1;
}

function valid_password($pw) {
    return is_string($pw) && strlen($pw) >= 8;
}

function s($v) { return is_string($v) ? trim($v) : $v; }

/* ------------------------------------------------------------
 * RATE LIMITING
 * ------------------------------------------------------------ */
function rate_limit_check($identifier) {
    $ip = client_ip();
    $window = (int)RATE_LIMIT_WINDOW_MIN;
    $max = (int)RATE_LIMIT_MAX;

    $count = (int)DB::col(
        "SELECT COUNT(*) FROM login_attempts
         WHERE ip = ? AND success = 0 AND created_at > DATE_SUB(NOW(), INTERVAL $window MINUTE)
           AND (identifier = ? OR identifier = '')",
        [$ip, $identifier]
    );
    return $count < $max;
}

function rate_limit_record($identifier, $success) {
    DB::insert('login_attempts', [
        'identifier' => (string)$identifier,
        'ip'         => client_ip(),
        'success'    => $success ? 1 : 0,
        'created_at' => date('Y-m-d H:i:s'),
    ]);
}

/* ------------------------------------------------------------
 * AUDIT
 * ------------------------------------------------------------ */
function audit($shop_id, $actor, $action, $details = null) {
    try {
        DB::insert('audit_log', [
            'shop_id'    => $shop_id,
            'actor'      => $actor,
            'action'     => $action,
            'details'    => $details ? json_encode($details, JSON_UNESCAPED_UNICODE) : null,
            'ip'         => client_ip(),
            'created_at' => date('Y-m-d H:i:s'),
        ]);
    } catch (Throwable $e) {
        error_log('Audit insert failed: ' . $e->getMessage());
    }
}

/* ------------------------------------------------------------
 * SHOP ID GENERATION
 * ------------------------------------------------------------ */
function generate_shop_id() {
    $max = (int)DB::col("SELECT COALESCE(MAX(id), 0) FROM shops");
    $n = $max + 100001; // first shop = PAD-100001
    do {
        $candidate = 'PAD-' . str_pad((string)$n, 6, '0', STR_PAD_LEFT);
        $exists = DB::col("SELECT 1 FROM shops WHERE shop_id = ?", [$candidate]);
        $n++;
    } while ($exists);
    return $candidate;
}

/* ------------------------------------------------------------
 * ADMIN SESSION (PHP native session — system_admin.php only)
 * ------------------------------------------------------------ */
function admin_session_start() {
    if (session_status() === PHP_SESSION_NONE) {
        session_set_cookie_params([
            'lifetime' => 0,
            'path'     => '/',
            'secure'   => true,
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
        session_start();
    }
}

function admin_is_logged_in() {
    admin_session_start();
    return !empty($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

function admin_login($email, $password) {
    if (!hash_equals(ADMIN_EMAIL, (string)$email)) return false;
    if (!hash_equals(ADMIN_PASS,  (string)$password)) return false;
    admin_session_start();
    $_SESSION['admin_logged_in'] = true;
    $_SESSION['admin_email'] = $email;
    $_SESSION['csrf'] = generate_token(24);
    return true;
}

function admin_logout() {
    admin_session_start();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

function csrf_token() {
    admin_session_start();
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = generate_token(24);
    return $_SESSION['csrf'];
}

function csrf_check($token) {
    admin_session_start();
    return !empty($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], (string)$token);
}

/* ------------------------------------------------------------
 * HTML ESCAPE
 * ------------------------------------------------------------ */
function h($s) {
    return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}