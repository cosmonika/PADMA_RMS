<?php
/**
 * PADMA RMS — Configuration
 * Do not expose this file. Deny direct web access via .htaccess.
 */
if (!defined('CONFIG_GUARD')) { http_response_code(403); exit('Forbidden'); }
define('CONFIG_GUARD', 1);

/* ------------------------------------------------------------
 * DATABASE
 * ------------------------------------------------------------ */
define('DB_HOST', 'localhost');
define('DB_NAME', 'odqqwmce_PADMA_RMS');
define('DB_USER', 'odqqwmce_PADMA_RMS');
define('DB_PASS', 'Sivabalan1#');
define('DB_CHARSET', 'utf8mb4');

/* ------------------------------------------------------------
 * APP
 * ------------------------------------------------------------ */
define('APP_NAME', 'PADMA RMS');
define('APP_URL', 'https://padma.cosmonika.com');
define('APP_TIMEZONE', 'Asia/Kolkata');
define('SESSION_TTL_DAYS', 30);          // client session validity
define('VERIFY_TTL_HOURS', 48);          // email verification link validity
define('RESET_TTL_HOURS', 2);            // password reset link validity
define('RATE_LIMIT_MAX', 5);             // failed attempts allowed
define('RATE_LIMIT_WINDOW_MIN', 15);     // in minutes

/* ------------------------------------------------------------
 * ADMIN (system administrator — creates shops)
 * After first login, change ADMIN_PASS here if needed.
 * ------------------------------------------------------------ */
define('ADMIN_EMAIL', 'admin@cosmonika.com');
define('ADMIN_PASS',  'SivaMorning#123Cosmonika');
define('ADMIN_NAME',  'Administrator');

/* ------------------------------------------------------------
 * MAIL (SMTP via PHPMailer)
 * ------------------------------------------------------------ */
define('SMTP_HOST',    'mail.cosmonika.com');
define('SMTP_PORT',    465);
define('SMTP_SECURE',  'ssl');           // 'ssl' (465) or 'tls' (587)
define('SMTP_USER',    'noreply@cosmonika.com');
define('SMTP_PASS',    'CosmoSivabalan1#');
define('MAIL_FROM',       'noreply@cosmonika.com');
define('MAIL_FROM_NAME',  'PADMA RMS');
define('ADMIN_NOTIFY_EMAIL', 'admin@cosmonika.com');

/* ------------------------------------------------------------
 * UPLOAD
 * ------------------------------------------------------------ */
define('UPLOAD_DIR', dirname(__DIR__) . '/upload/');
define('UPLOAD_URL', '/upload/');
define('UPLOAD_MAX_BYTES', 1048576);     // 1 MB
define('UPLOAD_MAX_DIM',   512);         // px

/* ------------------------------------------------------------
 * TIMEZONE
 * ------------------------------------------------------------ */
date_default_timezone_set(APP_TIMEZONE);

/* ------------------------------------------------------------
 * ERROR REPORTING (production-safe)
 * ------------------------------------------------------------ */
ini_set('display_errors', '0');
ini_set('display_startup_errors', '0');
error_reporting(E_ALL);
ini_set('log_errors', '1');
if (!is_dir(dirname(__DIR__) . '/logs')) { @mkdir(dirname(__DIR__) . '/logs', 0755, true); }
ini_set('error_log', dirname(__DIR__) . '/logs/php-error.log');