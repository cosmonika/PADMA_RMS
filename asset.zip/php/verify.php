<?php
/**
 * PADMA RMS — Email verification / password reset handler
 * Handles GET and POST. Renders simple HTML pages with app styling.
 */
define('CONFIG_GUARD', 1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/database.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/mailer.php';

function verify_page($title, $bodyHtml, $status = 'ok') {
    $color = $status === 'ok' ? '#10b981' : ($status === 'warn' ? '#f59e0b' : '#ef4444');
    $app = h(APP_NAME);
    $url = h(APP_URL);
    echo <<<HTML
<!DOCTYPE html>
<html><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{$title} — {$app}</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:-apple-system,'Segoe UI',system-ui,sans-serif;background:#f6f7fb;color:#111827;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:24px;font-size:14px;line-height:1.5}
  .wrap{max-width:480px;width:100%;background:#fff;border:1px solid #e5e8ee;border-radius:14px;box-shadow:0 20px 48px rgba(16,24,40,.08);overflow:hidden}
  .head{padding:22px 26px;background:#eef2ff;border-bottom:1px solid #e5e8ee}
  .brand{font-size:16px;font-weight:800;color:#4f46e5;letter-spacing:-.2px}
  .brand small{display:block;font-size:10px;color:#6b7280;font-weight:500;text-transform:uppercase;letter-spacing:1px;margin-top:2px}
  .body{padding:28px 26px}
  h1{font-size:19px;font-weight:700;margin-bottom:10px;color:{$color}}
  p{font-size:13.5px;color:#4b5563;margin-bottom:10px}
  .btn{display:inline-block;background:#6366f1;color:#fff;padding:11px 20px;border-radius:9px;font-weight:600;text-decoration:none;font-size:13px;margin-top:16px;border:none;cursor:pointer}
  .btn:hover{background:#4f46e5}
  .field{display:flex;flex-direction:column;gap:5px;margin-bottom:14px}
  .field label{font-size:12px;font-weight:600;color:#4b5563}
  .field input{height:38px;padding:0 12px;border:1px solid #e5e8ee;border-radius:8px;font-size:14px;outline:none;background:#fff;color:#111827}
  .field input:focus{border-color:#6366f1;box-shadow:0 0 0 3px #eef2ff}
  .err{background:#fee2e2;color:#ef4444;padding:10px 12px;border-radius:8px;font-size:12.5px;margin-bottom:14px}
</style></head><body><div class="wrap">
  <div class="head"><div class="brand">{$app}<small>Retail Management System</small></div></div>
  <div class="body">{$bodyHtml}</div>
</div></body></html>
HTML;
    exit;
}

/* ------------------------------------------------------------
 * EMAIL VERIFICATION (GET ?token=...)
 * ------------------------------------------------------------ */
if (isset($_GET['token'])) {
    $token = trim((string)$_GET['token']);
    if (!preg_match('/^[a-f0-9]{64,128}$/', $token)) {
        verify_page('Invalid Link', '<h1>Invalid link</h1><p>The verification link is malformed.</p>', 'err');
    }
    $row = DB::one(
        "SELECT ev.*, s.shop_id, s.email, s.status AS shop_status, s.owner_name, s.shop_name
         FROM email_verifications ev JOIN shops s ON s.id = ev.shop_ref
         WHERE ev.token = ? AND ev.purpose = 'verify_email' LIMIT 1",
        [$token]
    );
    if (!$row) {
        verify_page('Link Not Found', '<h1>Link not found</h1><p>This verification link is invalid or has already been used.</p>', 'err');
    }
    if ((int)$row['used'] === 1) {
        verify_page('Link Already Used', '<h1>Already verified</h1><p>Your account has already been verified. You can log in to the app now.</p><a class="btn" href="' . h(APP_URL) . '">Open App</a>', 'warn');
    }
    if (strtotime($row['expires_at']) < time()) {
        verify_page('Link Expired', '<h1>Link expired</h1><p>The verification link has expired. Please contact the administrator at <a href="mailto:' . h(ADMIN_NOTIFY_EMAIL) . '">' . h(ADMIN_NOTIFY_EMAIL) . '</a> to resend it.</p>', 'err');
    }

    // mark verified
    DB::begin();
    try {
        DB::update('email_verifications', ['used' => 1], 'id = :id', ['id' => $row['id']]);
        DB::update('shops', [
            'email_verified_at' => date('Y-m-d H:i:s'),
            'status'            => 'active',
            'updated_at'        => date('Y-m-d H:i:s'),
        ], 'id = :id', ['id' => $row['shop_ref']]);
        DB::commit();
    } catch (Throwable $e) {
        DB::rollback();
        error_log('verify error: ' . $e->getMessage());
        verify_page('Verification Failed', '<h1>Something went wrong</h1><p>Please try again or contact administrator.</p>', 'err');
    }

    audit($row['shop_ref'], 'system', 'email_verified', ['shop_id' => $row['shop_id']]);

    verify_page('Email Verified',
        '<h1>Email verified</h1>'
      . '<p>Welcome, ' . h($row['owner_name']) . '. Your email has been verified and your account is active.</p>'
      . '<p>Next step: go to the app, click <b>Register</b> &rarr; <b>I have Shop ID</b> and set your password using <b>' . h($row['shop_id']) . '</b>.</p>'
      . '<a class="btn" href="' . h(APP_URL) . '/?verified=1">Continue to App</a>', 'ok');
}

/* ------------------------------------------------------------
 * PASSWORD RESET (GET ?reset=... → form; POST → apply)
 * ------------------------------------------------------------ */
if (isset($_GET['reset']) || (isset($_POST['action']) && $_POST['action'] === 'reset_password')) {

    $token = trim((string)($_GET['reset'] ?? $_POST['token'] ?? ''));

    if (!preg_match('/^[a-f0-9]{64,128}$/', $token)) {
        verify_page('Invalid Link', '<h1>Invalid link</h1><p>The reset link is malformed.</p>', 'err');
    }

    $row = DB::one(
        "SELECT ev.*, s.shop_id, s.email FROM email_verifications ev
         JOIN shops s ON s.id = ev.shop_ref
         WHERE ev.token = ? AND ev.purpose = 'reset_password' LIMIT 1",
        [$token]
    );
    if (!$row || (int)$row['used'] === 1 || strtotime($row['expires_at']) < time()) {
        verify_page('Link Expired', '<h1>Link invalid or expired</h1><p>Please request a new password reset from the app.</p>', 'err');
    }

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'reset_password') {
        $pw  = (string)($_POST['password']  ?? '');
        $pw2 = (string)($_POST['password2'] ?? '');
        if (!valid_password($pw)) {
            verify_page('Weak Password',
                '<h1>Password too short</h1><p>Password must be at least 8 characters.</p>'
              . form_reset($token, 'Password must be at least 8 characters.'), 'err');
        }
        if ($pw !== $pw2) {
            verify_page('Passwords Do Not Match',
                '<h1>Passwords do not match</h1>' . form_reset($token, 'Passwords do not match.'), 'err');
        }
        DB::begin();
        try {
            DB::update('shops', [
                'password_hash' => password_hash($pw, PASSWORD_BCRYPT, ['cost' => 12]),
                'updated_at'    => date('Y-m-d H:i:s'),
            ], 'id = :id', ['id' => $row['shop_ref']]);
            DB::update('email_verifications', ['used' => 1], 'id = :id', ['id' => $row['id']]);
            DB::commit();
        } catch (Throwable $e) {
            DB::rollback();
            verify_page('Reset Failed', '<h1>Something went wrong</h1><p>Try again or contact admin.</p>', 'err');
        }
        audit($row['shop_ref'], 'system', 'password_reset', []);
        verify_page('Password Updated',
            '<h1>Password updated</h1>'
          . '<p>Your password has been changed. You can now log in with your new password.</p>'
          . '<a class="btn" href="' . h(APP_URL) . '">Open App</a>', 'ok');
    }

    // GET → show form
    verify_page('Reset Password',
        '<h1>Reset password</h1>'
      . '<p>Enter a new password for <b>' . h($row['shop_id']) . '</b>.</p>'
      . form_reset($token, ''), 'ok');
}

verify_page('Not Found', '<h1>Nothing to do</h1><p>This page is used only by email verification and password reset links.</p>', 'err');

/* ------------------------------------------------------------ */
function form_reset($token, $error) {
    $tok = h($token);
    $err = $error ? '<div class="err">' . h($error) . '</div>' : '';
    return <<<HTML
{$err}
<form method="post">
  <input type="hidden" name="action" value="reset_password">
  <input type="hidden" name="token" value="{$tok}">
  <div class="field"><label>New Password</label><input type="password" name="password" minlength="8" required autofocus></div>
  <div class="field"><label>Confirm Password</label><input type="password" name="password2" minlength="8" required></div>
  <button type="submit" class="btn">Update Password</button>
</form>
HTML;
}