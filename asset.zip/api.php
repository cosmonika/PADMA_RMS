<?php
define('CONFIG_GUARD', 1);
require_once __DIR__ . '/php/config.php';
require_once __DIR__ . '/php/database.php';
require_once __DIR__ . '/php/functions.php';
require_once __DIR__ . '/php/mailer.php';

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');

function camel_key($k, $o = []){ return $o[$k] ?? preg_replace_callback('/_([a-z])/', fn($m)=>strtoupper($m[1]), $k); }
function to_camel_row($row, $o = []){ if(!$row) return $row; $out=[]; foreach($row as $k=>$v) $out[camel_key($k,$o)]=$v; return $out; }
function to_camel_rows($rows, $o = []){ return array_map(fn($r)=>to_camel_row($r,$o), $rows ?: []); }

function shop_bootstrap($shop){
  $sid = (int)$shop['id'];
  $data = [
    'shop'           => shop_public($shop),
    'settings'       => shop_settings($shop),
    'categories'     => to_camel_rows(DB::all("SELECT * FROM categories WHERE shop_id = ? ORDER BY name", [$sid])),
    'products'       => to_camel_rows(DB::all("SELECT * FROM products WHERE shop_id = ? ORDER BY created_at DESC", [$sid])),
    'customers'      => to_camel_rows(DB::all("SELECT * FROM customers WHERE shop_id = ? ORDER BY name", [$sid])),
    'suppliers'      => to_camel_rows(DB::all("SELECT * FROM suppliers WHERE shop_id = ? ORDER BY business_name", [$sid])),
    'staff'          => to_camel_rows(DB::all("SELECT * FROM staff WHERE shop_id = ? ORDER BY name", [$sid])),
    'sales'          => to_camel_rows(DB::all("SELECT * FROM sales WHERE shop_id = ? ORDER BY date DESC LIMIT 500", [$sid])),
    'purchases'      => to_camel_rows(DB::all("SELECT * FROM purchases WHERE shop_id = ? ORDER BY date DESC LIMIT 500", [$sid]), ['paid'=>'amountPaid']),
    'stockMovements' => to_camel_rows(DB::all("SELECT * FROM stock_movements WHERE shop_id = ? ORDER BY date DESC LIMIT 500", [$sid])),
    'attendance'     => to_camel_rows(DB::all("SELECT * FROM attendance WHERE shop_id = ? ORDER BY date DESC", [$sid])),
    'payroll'        => to_camel_rows(DB::all("SELECT * FROM payroll WHERE shop_id = ? ORDER BY year DESC, month DESC", [$sid])),
    'cashTxns'       => to_camel_rows(DB::all("SELECT * FROM cash_txns WHERE shop_id = ? ORDER BY date DESC LIMIT 500", [$sid])),
    'expenses'       => to_camel_rows(DB::all("SELECT * FROM expenses WHERE shop_id = ? ORDER BY date DESC LIMIT 500", [$sid])),
    'tasks'          => to_camel_rows(DB::all("SELECT * FROM tasks WHERE shop_id = ? ORDER BY created_at DESC", [$sid])),
    'events'         => to_camel_rows(DB::all("SELECT * FROM events WHERE shop_id = ? ORDER BY date DESC", [$sid])),
    'heldBills'      => to_camel_rows(DB::all("SELECT * FROM held_bills WHERE shop_id = ? ORDER BY held_at DESC", [$sid])),
    'serverTime'     => date('c'),
  ];

  if (!empty($data['sales'])) {
    $ids = array_map(fn($s)=>$s['id'], $data['sales']);
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $items = DB::all("SELECT * FROM sale_items WHERE sale_id IN ($ph)", $ids);
    $pays  = DB::all("SELECT * FROM sale_payments WHERE sale_id IN ($ph)", $ids);
    $iByS=[]; foreach($items as $it) $iByS[$it['sale_id']][] = to_camel_row($it);
    $pByS=[]; foreach($pays  as $p)  $pByS[$p['sale_id']][] = to_camel_row($p, ['change_amount'=>'change']);
    foreach ($data['sales'] as &$s) { $s['items']=$iByS[$s['id']]??[]; $s['payments']=$pByS[$s['id']]??[]; } unset($s);
  }

  if (!empty($data['purchases'])) {
    $ids = array_map(fn($p)=>$p['id'], $data['purchases']);
    $ph = implode(',', array_fill(0, count($ids), '?'));
    $pitems = DB::all("SELECT * FROM purchase_items WHERE purchase_id IN ($ph)", $ids);
    $ppays  = DB::all("SELECT * FROM purchase_payments WHERE purchase_id IN ($ph) ORDER BY paid_at DESC", $ids);
    $iByP=[]; foreach($pitems as $it) $iByP[$it['purchase_id']][] = to_camel_row($it, ['cost'=>'price']);
    $paByP=[]; foreach($ppays as $p)  $paByP[$p['purchase_id']][] = to_camel_row($p);
    foreach ($data['purchases'] as &$p) {
      $p['items']    = $iByP[$p['id']]??[];
      $p['payments'] = $paByP[$p['id']]??[];
      if (!isset($p['paid'])) $p['paid'] = $p['amountPaid'] ?? 0;
    } unset($p);
  }

  foreach ($data['heldBills'] as &$hb) { $hb['cart'] = json_decode($hb['payload'] ?? '[]', true) ?: []; unset($hb['payload']); } unset($hb);

  return $data;
}

$shop = require_shop_auth();
$endpoint = $_GET['endpoint'] ?? '';
$body = request_data();

try {
switch ($endpoint) {

case 'bootstrap':
  json_ok(shop_bootstrap($shop)); break;

case 'crud':
  $entity = $body['entity'] ?? ''; $op = $body['op'] ?? ''; $id = $body['id'] ?? null; $data = $body['data'] ?? [];
  $sid = (int)$shop['id'];
  $allowed = ['categories','products','customers','suppliers','staff','cash_txns','expenses','tasks','events','held_bills'];
  if (!in_array($entity, $allowed, true)) json_err('Invalid entity', 400);
  $now = date('Y-m-d H:i:s');

  if ($op === 'create') {
    $row = crud_build_row($entity, $sid, $data, $now, null);
    DB::insert($entity, $row);
    if ($entity === 'products' && (int)$row['stock'] > 0) {
      DB::insert('stock_movements', [
        'shop_id'=>$sid,'product_id'=>$row['id'],'product_name'=>$row['name'],'type'=>'opening',
        'qty'=>(int)$row['stock'],'prev'=>0,'next'=>(int)$row['stock'],'reason'=>'Opening stock','date'=>$now,'created_at'=>$now,
      ]);
    }
    $saved = DB::one("SELECT * FROM `$entity` WHERE id = ? AND shop_id = ?", [$row['id'], $sid]);
    json_ok(['record' => to_camel_row($saved)]);
  }
  if ($op === 'update') {
    if (!$id) json_err('ID required', 400);
    $existing = DB::one("SELECT * FROM `$entity` WHERE id = ? AND shop_id = ?", [$id, $sid]);
    if (!$existing) json_err('Record not found', 404);
    $row = crud_build_row($entity, $sid, $data, $now, $existing);
    unset($row['id'], $row['shop_id'], $row['created_at']);
    $row['updated_at'] = $now;
    DB::update($entity, $row, 'id = :id AND shop_id = :sid', ['id'=>$id, 'sid'=>$sid]);
    $saved = DB::one("SELECT * FROM `$entity` WHERE id = ? AND shop_id = ?", [$id, $sid]);
    json_ok(['record' => to_camel_row($saved)]);
  }
  if ($op === 'delete') {
    if (!$id) json_err('ID required', 400);
    if ($entity === 'products') {
      if (DB::col("SELECT 1 FROM sale_items WHERE product_id = ? LIMIT 1", [$id])) json_err('Product used in sales — archive instead', 409);
    }
    DB::delete($entity, 'id = ? AND shop_id = ?', [$id, $sid]);
    json_ok(['deleted' => true]);
  }
  json_err('Invalid op', 400);
  break;

case 'sale.create':
  $sale = $body['sale'] ?? null;
  if (!$sale || empty($sale['items'])) json_err('Sale data required', 422);
  $sid = (int)$shop['id']; $now = date('Y-m-d H:i:s');
  $allowNeg = !empty(shop_settings($shop)['allowNegativeStock']);

  DB::begin();
  try {
    $invNext = (int)DB::col("SELECT invoice_next FROM shops WHERE id = ? FOR UPDATE", [$sid]);
    $prefix  = $shop['invoice_prefix'] ?: 'INV';
    $invoiceNo = $prefix . '-' . str_pad((string)$invNext, 5, '0', STR_PAD_LEFT);

    foreach ($sale['items'] as $it) {
      if (!empty($it['productId']) && !$allowNeg) {
        $p = DB::one("SELECT name, stock FROM products WHERE id = ? AND shop_id = ?", [$it['productId'], $sid]);
        if (!$p) json_err('Product not found', 400);
        if ((int)$p['stock'] < (int)$it['qty']) json_err('Not enough stock for '.$p['name'].' — only '.$p['stock'].' left', 409);
      }
    }

    $saleId = $sale['id'] ?? (uniqid('sale_', true) . bin2hex(random_bytes(4)));
    DB::insert('sales', [
      'id'=>$saleId, 'shop_id'=>$sid, 'invoice_no'=>$invoiceNo, 'date'=>$now,
      'customer_id'=>$sale['customerId'] ?: null, 'customer_name'=>$sale['customerName'] ?: 'Walk-in',
      'subtotal'=>(float)$sale['subtotal'], 'discount'=>(float)$sale['discount'], 'tax'=>(float)$sale['tax'],
      'additional_charges'=>(float)($sale['additionalCharges'] ?? 0), 'total'=>(float)$sale['total'],
      'amount_paid'=>(float)$sale['amountPaid'], 'balance'=>(float)$sale['balance'],
      'status'=>'completed', 'notes'=>$sale['notes'] ?? null, 'created_at'=>$now,
    ]);

    foreach ($sale['items'] as $it) {
      $line = (float)($it['lineTotal'] ?? ((float)$it['price'] * (int)$it['qty']));
      DB::insert('sale_items', [
        'sale_id'=>$saleId, 'product_id'=>$it['productId'] ?: null, 'name'=>$it['name'],
        'qty'=>(int)$it['qty'], 'price'=>(float)$it['price'], 'cost'=>(float)($it['cost'] ?? 0),
        'tax'=>(float)($it['tax'] ?? 0), 'discount'=>(float)($it['discount'] ?? 0), 'line_total'=>$line,
      ]);
      if (!empty($it['productId'])) {
        $prev = (int)DB::col("SELECT stock FROM products WHERE id = ? AND shop_id = ?", [$it['productId'], $sid]);
        $next = $prev - (int)$it['qty'];
        DB::update('products', ['stock'=>$next, 'updated_at'=>$now], 'id = :id AND shop_id = :sid', ['id'=>$it['productId'], 'sid'=>$sid]);
        DB::insert('stock_movements', [
          'shop_id'=>$sid,'product_id'=>$it['productId'],'product_name'=>$it['name'],'type'=>'sale',
          'qty'=>-(int)$it['qty'],'prev'=>$prev,'next'=>$next,'reference'=>$invoiceNo,'reason'=>'Sale','date'=>$now,'created_at'=>$now,
        ]);
      }
    }

    $method = 'Cash';
    foreach ($sale['payments'] ?? [] as $p) {
      $method = $p['method'] ?? 'Cash';
      DB::insert('sale_payments', [
        'sale_id'=>$saleId, 'method'=>$method, 'amount'=>(float)$p['amount'],
        'reference'=>$p['reference'] ?? null, 'change_amount'=>(float)($p['change'] ?? 0),
      ]);
    }
    if ($method === 'Cash' && (float)$sale['amountPaid'] > 0) {
      DB::insert('cash_txns', [
        'id'=>uniqid('cash_', true).bin2hex(random_bytes(3)),'shop_id'=>$sid,'type'=>'in',
        'amount'=>(float)min((float)$sale['amountPaid'],(float)$sale['total']),'method'=>'Cash',
        'category'=>'Sale','reference'=>$invoiceNo,'description'=>'Sale '.$invoiceNo,'date'=>$now,'created_at'=>$now,
      ]);
    }
    if (!empty($sale['customerId'])) {
      DB::run("UPDATE customers SET total_purchases=total_purchases+?, transactions=transactions+1, last_purchase_at=?, balance=balance+?, updated_at=? WHERE id=? AND shop_id=?",
        [(float)$sale['total'], $now, $method==='Credit'?(float)$sale['total']:0.0, $now, $sale['customerId'], $sid]);
    }
    DB::run("UPDATE shops SET invoice_next=invoice_next+1, onboarding_done=1, updated_at=? WHERE id=?", [$now, $sid]);
    DB::commit();
  } catch (Throwable $e) {
    DB::rollback();
    if (strpos($e->getMessage(), 'Not enough') !== false) json_err($e->getMessage(), 409);
    error_log('sale.create: '.$e->getMessage());
    json_err('Sale failed: '.$e->getMessage(), 500);
  }

  $row = to_camel_row(DB::one("SELECT * FROM sales WHERE id=?", [$saleId]));
  $row['items'] = to_camel_rows(DB::all("SELECT * FROM sale_items WHERE sale_id=?", [$saleId]));
  $row['payments'] = to_camel_rows(DB::all("SELECT * FROM sale_payments WHERE sale_id=?", [$saleId]), ['change_amount'=>'change']);
  $stocks = [];
  foreach ($sale['items'] as $it) if (!empty($it['productId'])) $stocks[$it['productId']] = (int)DB::col("SELECT stock FROM products WHERE id=?", [$it['productId']]);
  json_ok(['sale'=>$row, 'productStocks'=>$stocks, 'invoiceNext'=>$invNext+1]);
  break;

case 'sale.cancel':
  $id = $body['id'] ?? ''; if (!$id) json_err('ID required', 422);
  $sid = (int)$shop['id'];
  $sale = DB::one("SELECT * FROM sales WHERE id=? AND shop_id=?", [$id, $sid]);
  if (!$sale) json_err('Sale not found', 404);
  if ($sale['status'] === 'cancelled') json_err('Already cancelled', 409);
  $now = date('Y-m-d H:i:s');
  DB::begin();
  try {
    foreach (DB::all("SELECT * FROM sale_items WHERE sale_id=?", [$id]) as $it) {
      if (!empty($it['product_id'])) {
        $prev = (int)DB::col("SELECT stock FROM products WHERE id=? AND shop_id=?", [$it['product_id'], $sid]);
        $next = $prev + (int)$it['qty'];
        DB::update('products', ['stock'=>$next, 'updated_at'=>$now], 'id=:id AND shop_id=:sid', ['id'=>$it['product_id'], 'sid'=>$sid]);
        DB::insert('stock_movements', [
          'shop_id'=>$sid,'product_id'=>$it['product_id'],'product_name'=>$it['name'],'type'=>'return',
          'qty'=>(int)$it['qty'],'prev'=>$prev,'next'=>$next,'reference'=>$sale['invoice_no'],'reason'=>'Cancelled','date'=>$now,'created_at'=>$now,
        ]);
      }
    }
    if (!empty($sale['customer_id'])) {
      $wasCredit = false;
      foreach (DB::all("SELECT * FROM sale_payments WHERE sale_id=?", [$id]) as $p) if ($p['method'] === 'Credit') $wasCredit = true;
      DB::run("UPDATE customers SET total_purchases=GREATEST(0,total_purchases-?), transactions=GREATEST(0,transactions-1), balance=GREATEST(0,balance-?), updated_at=? WHERE id=? AND shop_id=?",
        [(float)$sale['total'], $wasCredit?(float)$sale['total']:0.0, $now, $sale['customer_id'], $sid]);
    }
    DB::update('sales', ['status'=>'cancelled'], 'id=:id AND shop_id=:sid', ['id'=>$id, 'sid'=>$sid]);
    DB::commit();
  } catch (Throwable $e) { DB::rollback(); json_err('Cancel failed: '.$e->getMessage(), 500); }
  json_ok(['cancelled'=>true]);
  break;

case 'purchase.create':
  $pur = $body['purchase'] ?? null;
  if (!$pur || empty($pur['items'])) json_err('Purchase required', 422);
  $sid = (int)$shop['id']; $now = date('Y-m-d H:i:s');
  $amountPaid = isset($pur['amountPaid']) ? (float)$pur['amountPaid'] : (float)($pur['paid'] ?? 0);
  $method = $pur['paymentMethod'] ?? 'Cash';

  DB::begin();
  try {
    $purId = $pur['id'] ?? (uniqid('pur_', true) . bin2hex(random_bytes(4)));
    $invNo = $pur['invoiceNo'] ?: ('PUR-' . date('YmdHis') . '-' . random_int(100,999));
    $total = (float)($pur['total'] ?? 0);
    $pending = max(0, $total - $amountPaid);
    DB::insert('purchases', [
      'id'=>$purId,'shop_id'=>$sid,'invoice_no'=>$invNo,'date'=>$now,
      'supplier_id'=>$pur['supplierId'] ?: null, 'supplier_name'=>$pur['supplierName'] ?: '—',
      'subtotal'=>(float)($pur['subtotal'] ?? $total), 'tax'=>(float)($pur['tax'] ?? 0),
      'total'=>$total, 'paid'=>$amountPaid, 'balance'=>$pending,
      'status'=>'received', 'notes'=>$pur['notes'] ?? null, 'created_at'=>$now,
    ]);
    foreach ($pur['items'] as $it) {
      $unitCost = isset($it['cost']) ? (float)$it['cost'] : (float)($it['price'] ?? 0);
      $line = (float)($it['lineTotal'] ?? ($unitCost * (int)$it['qty']));
      DB::insert('purchase_items', [
        'purchase_id'=>$purId,'product_id'=>$it['productId'] ?: null,'name'=>$it['name'],
        'qty'=>(int)$it['qty'],'cost'=>$unitCost,'line_total'=>$line,
      ]);
      if (!empty($it['productId'])) {
        $prev = (int)DB::col("SELECT stock FROM products WHERE id=? AND shop_id=?", [$it['productId'], $sid]);
        $next = $prev + (int)$it['qty'];
        DB::update('products', ['stock'=>$next, 'purchase_price'=>$unitCost, 'updated_at'=>$now], 'id=:id AND shop_id=:sid', ['id'=>$it['productId'], 'sid'=>$sid]);
        DB::insert('stock_movements', [
          'shop_id'=>$sid,'product_id'=>$it['productId'],'product_name'=>$it['name'],'type'=>'purchase',
          'qty'=>(int)$it['qty'],'prev'=>$prev,'next'=>$next,'reference'=>$invNo,'reason'=>'Purchase','date'=>$now,'created_at'=>$now,
        ]);
      }
    }
    if ($amountPaid > 0) {
      DB::insert('purchase_payments', [
        'purchase_id'=>$purId,'method'=>$method,'amount'=>$amountPaid,'reference'=>'Initial payment','paid_at'=>$now,'created_at'=>$now,
      ]);
      if ($method === 'Cash') {
        DB::insert('cash_txns', [
          'id'=>uniqid('cash_', true).bin2hex(random_bytes(3)),'shop_id'=>$sid,'type'=>'out',
          'amount'=>$amountPaid,'method'=>'Cash','category'=>'Purchase','reference'=>$invNo,
          'description'=>'Purchase payment '.$invNo,'date'=>$now,'created_at'=>$now,
        ]);
      }
    }
    if (!empty($pur['supplierId']) && $pending > 0.01) {
      DB::run("UPDATE suppliers SET balance=balance+?, updated_at=? WHERE id=? AND shop_id=?", [$pending, $now, $pur['supplierId'], $sid]);
    }
    DB::commit();
  } catch (Throwable $e) { DB::rollback(); error_log('purchase.create: '.$e->getMessage()); json_err('Purchase failed: '.$e->getMessage(), 500); }

  $row = to_camel_row(DB::one("SELECT * FROM purchases WHERE id=?", [$purId]), ['paid'=>'amountPaid']);
  $row['items']    = to_camel_rows(DB::all("SELECT * FROM purchase_items WHERE purchase_id=?", [$purId]), ['cost'=>'price']);
  $row['payments'] = to_camel_rows(DB::all("SELECT * FROM purchase_payments WHERE purchase_id=?", [$purId]));
  json_ok(['purchase'=>$row]);
  break;

case 'purchase.payment':
  $pid = $body['id'] ?? ''; $amount = (float)($body['amount'] ?? 0);
  $method = $body['method'] ?? 'Cash'; $ref = $body['reference'] ?? '';
  if (!$pid || $amount <= 0) json_err('ID and amount required', 422);
  $sid = (int)$shop['id']; $now = date('Y-m-d H:i:s');
  DB::begin();
  try {
    $pur = DB::one("SELECT * FROM purchases WHERE id=? AND shop_id=? FOR UPDATE", [$pid, $sid]);
    if (!$pur) json_err('Purchase not found', 404);
    $pending = (float)$pur['total'] - (float)$pur['paid'];
    if ($amount > $pending + 0.01) json_err('Amount exceeds pending balance', 400);
    $newPaid = (float)$pur['paid'] + $amount;
    $newBalance = max(0, (float)$pur['total'] - $newPaid);
    DB::update('purchases', ['paid'=>$newPaid, 'balance'=>$newBalance], 'id=:id', ['id'=>$pid]);
    DB::insert('purchase_payments', [
      'purchase_id'=>$pid,'method'=>$method,'amount'=>$amount,'reference'=>$ref,'paid_at'=>$now,'created_at'=>$now,
    ]);
    if (!empty($pur['supplier_id'])) {
      DB::run("UPDATE suppliers SET balance=GREATEST(0,balance-?), updated_at=? WHERE id=? AND shop_id=?", [$amount, $now, $pur['supplier_id'], $sid]);
    }
    if ($method === 'Cash') {
      DB::insert('cash_txns', [
        'id'=>uniqid('cash_', true).bin2hex(random_bytes(3)),'shop_id'=>$sid,'type'=>'out',
        'amount'=>$amount,'method'=>'Cash','category'=>'Purchase Payment',
        'reference'=>$pur['invoice_no'],'description'=>'Payment for '.$pur['invoice_no'],'date'=>$now,'created_at'=>$now,
      ]);
    }
    DB::commit();
  } catch (Throwable $e) { DB::rollback(); json_err($e->getMessage(), 500); }
  json_ok(['amountPaid'=>$newPaid, 'balance'=>$newBalance]);
  break;

case 'attendance.bulk':
  $recs = $body['records'] ?? [];
  if (!is_array($recs) || !$recs) json_err('Records required', 422);
  $sid = (int)$shop['id']; $now = date('Y-m-d H:i:s');
  DB::begin();
  try {
    foreach ($recs as $r) {
      $sid_ = $r['staffId'] ?? ''; $date = $r['date'] ?? ''; $st = $r['status'] ?? '';
      if (!$sid_ || !$date || !in_array($st, ['P','A','H','L'], true)) continue;
      DB::run("INSERT INTO attendance (shop_id, staff_id, date, status, notes, created_at) VALUES (?,?,?,?,?,?) ON DUPLICATE KEY UPDATE status=VALUES(status), notes=VALUES(notes)",
        [$sid, $sid_, $date, $st, $r['notes'] ?? null, $now]);
    }
    DB::commit();
  } catch (Throwable $e) { DB::rollback(); json_err('Attendance failed: '.$e->getMessage(), 500); }
  json_ok(['saved'=>count($recs)]);
  break;

case 'payroll.generate':
  $month = (int)($body['month'] ?? 0); $year = (int)($body['year'] ?? 0);
  $recoverAdvances = $body['recoverAdvances'] ?? [];
  if ($month < 1 || $month > 12 || $year < 2000 || $year > 2100) json_err('Invalid month/year', 422);
  $sid = (int)$shop['id']; $now = date('Y-m-d H:i:s');
  $staff = DB::all("SELECT * FROM staff WHERE shop_id=? AND status='active'", [$sid]);
  if (!$staff) json_err('No active staff', 400);
  $created = 0;
  DB::begin();
  try {
    foreach ($staff as $st) {
      $exists = DB::col("SELECT 1 FROM payroll WHERE shop_id=? AND staff_id=? AND month=? AND year=?", [$sid, $st['id'], $month, $year]);
      if ($exists) continue;
      DB::insert('payroll', [
        'shop_id'=>$sid,'staff_id'=>$st['id'],'month'=>$month,'year'=>$year,
        'base_salary'=>(float)$st['salary'],'allowance'=>0,'deduction'=>0,
        'net_pay'=>(float)$st['salary'],'status'=>'pending','notes'=>null,'created_at'=>$now,
      ]);
      $created++;
    }
    foreach ($recoverAdvances as $ra) {
      $expId = $ra['expenseId'] ?? ''; $amt = (float)($ra['amount'] ?? 0);
      if (!$expId || $amt <= 0) continue;
      $exp = DB::one("SELECT * FROM expenses WHERE id=? AND shop_id=?", [$expId, $sid]);
      if (!$exp) continue;
      $newRec = (float)$exp['recovered_amount'] + $amt;
      $fullyRecovered = $newRec >= (float)$exp['amount'] - 0.01 ? 1 : 0;
      DB::update('expenses', ['recovered_amount'=>$newRec, 'recovered'=>$fullyRecovered], 'id=:id', ['id'=>$expId]);
    }
    DB::commit();
  } catch (Throwable $e) { DB::rollback(); json_err($e->getMessage(), 500); }
  json_ok(['created'=>$created]);
  break;

case 'payroll.pay':
  $id = (int)($body['id'] ?? 0); if (!$id) json_err('ID required', 422);
  $sid = (int)$shop['id']; $now = date('Y-m-d H:i:s');
  DB::begin();
  try {
    $p = DB::one("SELECT * FROM payroll WHERE id=? AND shop_id=? FOR UPDATE", [$id, $sid]);
    if (!$p) json_err('Payroll not found', 404);
    if ($p['status'] === 'paid') json_err('Already paid', 409);
    DB::update('payroll', ['status'=>'paid', 'paid_at'=>$now], 'id=:id', ['id'=>$id]);
    $staffName = DB::col("SELECT name FROM staff WHERE id=?", [$p['staff_id']]) ?: 'Staff';
    DB::insert('expenses', [
      'id'=>uniqid('exp_', true).bin2hex(random_bytes(3)),'shop_id'=>$sid,'category'=>'Salary',
      'description'=>'Salary — '.$staffName.' ('.$p['month'].'/'.$p['year'].')',
      'amount'=>(float)$p['net_pay'],'date'=>$now,'payment_method'=>'Cash','created_at'=>$now,
    ]);
    DB::insert('cash_txns', [
      'id'=>uniqid('cash_', true).bin2hex(random_bytes(3)),'shop_id'=>$sid,'type'=>'out',
      'amount'=>(float)$p['net_pay'],'method'=>'Cash','category'=>'Salary',
      'reference'=>(string)$id,'description'=>'Salary '.$staffName,'date'=>$now,'created_at'=>$now,
    ]);
    DB::commit();
  } catch (Throwable $e) { DB::rollback(); json_err($e->getMessage(), 500); }
  json_ok(['paid'=>true]);
  break;

case 'settings.update':
  $sd = $body['shop'] ?? []; $ns = $body['settings'] ?? [];
  $sid = (int)$shop['id']; $now = date('Y-m-d H:i:s');
  $merge = array_merge(shop_settings($shop), $ns);
  $update = [
    'shop_name'       => $sd['name'] ?? $shop['shop_name'],
    'owner_name'      => $sd['ownerName'] ?? $shop['owner_name'],
    'gstin'           => $sd['gstin'] ?? $shop['gstin'],
    'address'         => $sd['address'] ?? $shop['address'],
    'city'            => $sd['city'] ?? $shop['city'],
    'state'           => $sd['state'] ?? $shop['state'],
    'pincode'         => $sd['pincode'] ?? $shop['pincode'],
    'country'         => $sd['country'] ?? $shop['country'],
    'currency'        => $sd['currency'] ?? $shop['currency'],
    'currency_symbol' => $sd['currencySymbol'] ?? $shop['currency_symbol'],
    'invoice_prefix'  => $sd['invoicePrefix'] ?? $shop['invoice_prefix'],
    'settings_json'   => json_encode($merge, JSON_UNESCAPED_UNICODE),
    'onboarding_done' => 1, 'updated_at' => $now,
  ];
  if (isset($sd['invoiceNext']) && (int)$sd['invoiceNext'] > 0) $update['invoice_next'] = (int)$sd['invoiceNext'];
  DB::update('shops', $update, 'id=:id', ['id'=>$sid]);
  $fresh = DB::one("SELECT * FROM shops WHERE id=?", [$sid]);
  json_ok(['shop'=>shop_public($fresh), 'settings'=>shop_settings($fresh)]);
  break;

case 'upload':
  if (empty($_FILES['file'])) json_err('No file', 422);
  $f = $_FILES['file'];
  if ($f['error'] !== UPLOAD_ERR_OK) json_err('Upload error '.$f['error'], 400);
  if ($f['size'] > UPLOAD_MAX_BYTES) json_err('Max 1 MB', 400);
  $info = @getimagesize($f['tmp_name']);
  if (!$info || !in_array($info[2], [IMAGETYPE_JPEG, IMAGETYPE_PNG, IMAGETYPE_WEBP], true)) json_err('Only JPG/PNG/WEBP', 400);
  $src = @imagecreatefromstring(file_get_contents($f['tmp_name']));
  if (!$src) json_err('Cannot read image', 400);
  $w = imagesx($src); $h = imagesy($src);
  $scale = min(1, UPLOAD_MAX_DIM / max($w, $h));
  $nw = max(1, (int)round($w * $scale)); $nh = max(1, (int)round($h * $scale));
  $dst = imagecreatetruecolor($nw, $nh); imagealphablending($dst, false); imagesavealpha($dst, true);
  imagecopyresampled($dst, $src, 0, 0, 0, 0, $nw, $nh, $w, $h);
  $dir = UPLOAD_DIR . 'logos/'; if (!is_dir($dir)) @mkdir($dir, 0755, true);
  $sid = (int)$shop['id'];
  $filename = 'shop_'.$sid.'_'.time().'.png';
  imagepng($dst, $dir.$filename, 8); imagedestroy($src); imagedestroy($dst);
  $rel = '/upload/logos/'.$filename;
  DB::update('shops', ['logo_path'=>$rel, 'updated_at'=>date('Y-m-d H:i:s')], 'id=:id', ['id'=>$sid]);
  json_ok(['path'=>$rel, 'url'=>APP_URL.$rel]);
  break;

case 'sync.changes':
  $since = $body['since'] ?? null;
  $sid = (int)$shop['id'];
  if (!$since) { json_ok(['changed'=>true, 'bootstrap'=>shop_bootstrap($shop)]); }
  $ts = strtotime($since);
  if ($ts === false) { json_ok(['changed'=>true, 'bootstrap'=>shop_bootstrap($shop)]); }
  $sinceDt = date('Y-m-d H:i:s', $ts);
  $changed = false;

  foreach (['categories','products','customers','suppliers','staff','tasks'] as $t) {
    if (DB::col("SELECT 1 FROM `$t` WHERE shop_id=? AND (created_at>? OR updated_at>?) LIMIT 1", [$sid, $sinceDt, $sinceDt])) { $changed=true; break; }
  }
  if (!$changed) {
    foreach (['sales','purchases','stock_movements','attendance','payroll','cash_txns','expenses','events','held_bills'] as $t) {
      if (DB::col("SELECT 1 FROM `$t` WHERE shop_id=? AND created_at>? LIMIT 1", [$sid, $sinceDt])) { $changed=true; break; }
    }
  }
  if (!$changed) {
    if (DB::col("SELECT 1 FROM purchase_payments pp JOIN purchases p ON p.id=pp.purchase_id WHERE p.shop_id=? AND pp.created_at>? LIMIT 1", [$sid, $sinceDt])) $changed=true;
  }
  if (!$changed && DB::col("SELECT 1 FROM shops WHERE id=? AND updated_at>? LIMIT 1", [$sid, $sinceDt])) $changed=true;

  if ($changed) json_ok(['changed'=>true, 'bootstrap'=>shop_bootstrap($shop)]);
  else json_ok(['changed'=>false, 'serverTime'=>date('c')]);
  break;

case 'export':
  json_ok(shop_bootstrap($shop)); break;

default:
  json_err('Unknown endpoint', 404);
}
} catch (Throwable $e) {
  error_log('api.php ['.$endpoint.']: '.$e->getMessage());
  json_err('Server error: '.$e->getMessage(), 500);
}

function crud_build_row($entity, $sid, $data, $now, $existing){
  $id = $existing['id'] ?? ($data['id'] ?? (uniqid(substr($entity,0,4).'_', true) . bin2hex(random_bytes(3))));
  $row = ['id'=>$id, 'shop_id'=>$sid];
  switch ($entity) {
    case 'categories':
      if (isset($data['name']))        $row['name']        = trim((string)$data['name']);
      if (isset($data['description'])) $row['description'] = (string)$data['description'];
      if (isset($data['colorIdx']))    $row['color_idx']   = (int)$data['colorIdx'];
      if (!$existing) { if (empty($row['name'])) json_err('Category name required', 422); $row['created_at']=$now; }
      break;
    case 'products':
      foreach (['name'=>'name','sku'=>'sku','barcode'=>'barcode','brand'=>'brand','unit'=>'unit','description'=>'description'] as $k=>$c) if (isset($data[$k])) $row[$c]=(string)$data[$k];
      if (isset($data['categoryId']))    $row['category_id']    = $data['categoryId'] ?: null;
      if (isset($data['supplierId']))    $row['supplier_id']    = $data['supplierId'] ?: null;
      if (isset($data['purchasePrice'])) $row['purchase_price'] = (float)$data['purchasePrice'];
      if (isset($data['sellingPrice']))  $row['selling_price']  = (float)$data['sellingPrice'];
      if (isset($data['mrp']))           $row['mrp']            = (float)$data['mrp'];
      if (isset($data['stock']))         $row['stock']          = (int)$data['stock'];
      if (isset($data['minStock']))      $row['min_stock']      = (int)$data['minStock'];
      if (isset($data['tax']))           $row['tax']            = (float)$data['tax'];
      if (isset($data['colorIdx']))      $row['color_idx']      = (int)$data['colorIdx'];
      if (isset($data['status']))        $row['status']         = in_array($data['status'],['active','archived'],true)?$data['status']:'active';
      if (!$existing) { if (empty($row['name'])) json_err('Name required', 422); if (empty($row['unit'])) $row['unit']='pcs'; if (empty($row['status'])) $row['status']='active'; $row['created_at']=$now; }
      break;
    case 'customers':
      foreach (['name'=>'name','mobile'=>'mobile','email'=>'email','address'=>'address','city'=>'city','gstin'=>'gstin','notes'=>'notes'] as $k=>$c) if (isset($data[$k])) $row[$c]=(string)$data[$k];
      if (isset($data['balance'])) $row['balance'] = (float)$data['balance'];
      if (!$existing) { if (empty($row['name'])) json_err('Name required', 422); $row['created_at']=$now; }
      break;
    case 'suppliers':
      foreach (['businessName'=>'business_name','contactPerson'=>'contact_person','mobile'=>'mobile','email'=>'email','address'=>'address','gstin'=>'gstin','notes'=>'notes'] as $k=>$c) if (isset($data[$k])) $row[$c]=(string)$data[$k];
      if (isset($data['balance'])) $row['balance'] = (float)$data['balance'];
      if (!$existing) { if (empty($row['business_name'])) json_err('Business name required', 422); $row['created_at']=$now; }
      break;
    case 'staff':
      foreach (['name'=>'name','role'=>'role','mobile'=>'mobile','email'=>'email','address'=>'address','notes'=>'notes'] as $k=>$c) if (isset($data[$k])) $row[$c]=(string)$data[$k];
      // Support extra fields from index.html (designation, employeeId, department)
      if (isset($data['designation'])) $row['role'] = (string)$data['designation'];
      if (isset($data['joinDate'])) $row['join_date'] = $data['joinDate'] ?: null;
      if (isset($data['salary']))   $row['salary']    = (float)$data['salary'];
      if (isset($data['status']))   $row['status']    = in_array($data['status'],['active','inactive'],true)?$data['status']:'active';
      if (!$existing) { if (empty($row['name'])) json_err('Name required', 422); if (empty($row['status'])) $row['status']='active'; $row['created_at']=$now; }
      break;
    case 'cash_txns':
      if (isset($data['type']))        $row['type']        = in_array($data['type'],['in','out'],true)?$data['type']:'in';
      if (isset($data['amount']))      $row['amount']      = (float)$data['amount'];
      if (isset($data['method']))      $row['method']      = (string)$data['method'];
      if (isset($data['category']))    $row['category']    = (string)$data['category'];
      if (isset($data['reference']))   $row['reference']   = (string)$data['reference'];
      if (isset($data['description'])) $row['description'] = (string)$data['description'];
      if (isset($data['date']))        $row['date']        = $data['date'];
      if (!$existing) { if (!isset($row['amount'])) json_err('Amount required', 422); if (empty($row['method'])) $row['method']='Cash'; if (empty($row['date'])) $row['date']=$now; $row['created_at']=$now; }
      break;
    case 'expenses':
      if (isset($data['category']))        $row['category']         = (string)$data['category'];
      if (isset($data['description']))     $row['description']      = (string)$data['description'];
      if (isset($data['amount']))          $row['amount']           = (float)$data['amount'];
      if (isset($data['paymentMethod']))   $row['payment_method']   = (string)$data['paymentMethod'];
      if (isset($data['notes']))           $row['notes']            = (string)$data['notes'];
      if (isset($data['staffId']))         $row['staff_id']         = $data['staffId'] ?: null;
      if (isset($data['staffName']))       $row['staff_name']       = (string)$data['staffName'];
      if (isset($data['recovered']))       $row['recovered']        = (int)$data['recovered'];
      if (isset($data['recoveredAmount'])) $row['recovered_amount'] = (float)$data['recoveredAmount'];
      if (isset($data['date']))            $row['date']             = $data['date'];
      if (!$existing) { if (!isset($row['amount'])) json_err('Amount required', 422); if (empty($row['date'])) $row['date']=$now; $row['created_at']=$now; }
      break;
    case 'tasks':
      if (isset($data['title']))       $row['title']       = trim((string)$data['title']);
      if (isset($data['description'])) $row['description'] = (string)$data['description'];
      if (isset($data['priority']))    $row['priority']    = in_array($data['priority'],['Low','Medium','High','Urgent'],true)?$data['priority']:'Low';
      if (isset($data['status']))      $row['status']      = in_array($data['status'],['Pending','In Progress','Review','Completed','Cancelled'],true)?$data['status']:'Pending';
      if (isset($data['dueDate']))     $row['due_date']    = $data['dueDate'] ?: null;
      if (isset($data['assignedTo']))  $row['assigned_to'] = $data['assignedTo'] ?: null;
      if (!$existing) { if (empty($row['title'])) json_err('Title required', 422); $row['created_at']=$now; }
      break;
    case 'events':
      if (isset($data['title']))       $row['title']       = trim((string)$data['title']);
      if (isset($data['description'])) $row['description'] = (string)$data['description'];
      if (isset($data['date']))        $row['date']        = $data['date'];
      if (isset($data['time']))        $row['time']        = (string)$data['time'];
      if (isset($data['colorIdx']))    $row['color_idx']   = (int)$data['colorIdx'];
      if (!$existing) { if (empty($row['title'])) json_err('Title required', 422); if (empty($row['date'])) json_err('Date required', 422); $row['created_at']=$now; }
      break;
    case 'held_bills':
      if (isset($data['cart']))              $row['payload']            = json_encode($data['cart'], JSON_UNESCAPED_UNICODE);
      if (isset($data['customerId']))        $row['customer_id']        = $data['customerId'] ?: null;
      if (isset($data['discount']))          $row['discount']           = (float)$data['discount'];
      if (isset($data['additionalCharges'])) $row['additional_charges'] = (float)$data['additionalCharges'];
      if (!$existing) { $row['held_at'] = $now; $row['created_at'] = $now; }
      break;
  }
  return $row;
}