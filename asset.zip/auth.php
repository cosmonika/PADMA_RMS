<?php
/**
 * PADMA RMS — Authentication endpoints
 *   POST ?action=login         { shop_id, email, password }         → { token, shop }
 *   POST ?action=logout        (Bearer token)                       → { }
 *   POST ?action=check-shop    { shop_id }                          → { shop_id, shop_name, email_masked, mobile_masked, has_password }
 *   POST ?action=set-password  { shop_id, password, password2 }     → { message }
 *   POST ?action=forgot        { shop_id, email }                   → { message }
 */
define('CONFIG_GUARD', 1);
require_once __DIR__ . '/php/config.php';
require_once __DIR__ . '/php/database.php';
require_once __DIR__ . '/php/functions.php';
require_once __DIR__ . '/php/mailer.php';

header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Cache-Control: no-store');

$action = $_GET['action'] ?? '';
$body   = request_data();

switch ($action) {

/* ------------------------------------------------------------
 * LOGIN
 * ------------------------------------------------------------ */
case 'login':
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST required', 405);
    $shopId   = trim((string)($body['shop_id'] ?? ''));
    $email    = strtolower(trim((string)($body['email'] ?? '')));
    $password = (string)($body['password'] ?? '');

    if (!$shopId || !$email || !$password) json_err('Shop ID, email and password are required', 422);
    if (!valid_shop_id($shopId)) json_err('Invalid Shop ID format', 422);
    if (!valid_email($email))     json_err('Invalid email', 422);

    if (!rate_limit_check($shopId)) {
        json_err('Too many failed attempts. Please wait 15 minutes and try again.', 429);
    }

    $shop = DB::one("SELECT * FROM shops WHERE shop_id = ? AND LOWER(email) = ? LIMIT 1", [$shopId, $email]);
    if (!$shop) { rate_limit_record($shopId, false); json_err('Invalid Shop ID, email or password', 401); }

    if ($shop['status'] === 'pending') {
        rate_limit_record($shopId, false);
        json_err('Your email is not verified yet. Please click the link in your verification email.', 403);
    }
    if ($shop['status'] === 'suspended') json_err('This account has been suspended. Contact administrator.', 403);
    if ($shop['status'] === 'expired')   json_err('License expired. Contact administrator.', 403);
    if ($shop['status'] !== 'active')    json_err('Account is not active', 403);
    if (!$shop['password_hash']) {
        json_err('No password set. Click "Register", choose "I have a Shop ID", and set your password first.', 403);
    }
    if (!password_verify($password, $shop['password_hash'])) {
        rate_limit_record($shopId, false);
        json_err('Invalid Shop ID, email or password', 401);
    }

    rate_limit_record($shopId, true);

    $token = generate_token(48);
    DB::insert('sessions', [
        'shop_ref'     => (int)$shop['id'],
        'token_hash'   => hash_token($token),
        'device'       => user_agent(),
        'ip'           => client_ip(),
        'expires_at'   => date('Y-m-d H:i:s', time() + SESSION_TTL_DAYS * 86400),
        'last_used_at' => date('Y-m-d H:i:s'),
        'created_at'   => date('Y-m-d H:i:s'),
    ]);
    DB::update('shops', ['last_login_at' => date('Y-m-d H:i:s')], 'id = :id', ['id' => $shop['id']]);
    audit((int)$shop['id'], $shop['email'], 'login', ['ip' => client_ip()]);

    json_ok(['token' => $token, 'shop' => shop_public($shop)]);
    break;

/* ------------------------------------------------------------
 * LOGOUT
 * ------------------------------------------------------------ */
case 'logout':
    $token = bearer_token();
    if ($token) {
        DB::run("DELETE FROM sessions WHERE token_hash = ?", [hash_token($token)]);
    }
    json_ok([]);
    break;

/* ------------------------------------------------------------
 * CHECK SHOP (Step 1 of "I have a Shop ID")
 * ------------------------------------------------------------ */
case 'check-shop':
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST required', 405);
    $shopId = trim((string)($body['shop_id'] ?? ''));
    if (!valid_shop_id($shopId)) json_err('Invalid Shop ID format', 422);
    if (!rate_limit_check($shopId)) json_err('Too many attempts. Try again in 15 minutes.', 429);

    $shop = DB::one("SELECT * FROM shops WHERE shop_id = ? LIMIT 1", [$shopId]);
    if (!$shop) { rate_limit_record($shopId, false); json_err('Shop ID not found', 404); }
    if ($shop['status'] !== 'active' && $shop['status'] !== 'pending') {
        json_err('This shop is ' . $shop['status'] . '. Contact administrator.', 403);
    }
    if (!$shop['email_verified_at']) {
        json_err('Email for this shop is not verified yet. Please contact administrator.', 403);
    }

    json_ok([
        'shop_id'       => $shop['shop_id'],
        'shop_name'     => $shop['shop_name'],
        'email_masked'  => mask_email($shop['email']),
        'mobile_masked' => mask_mobile($shop['mobile']),
        'has_password'  => !empty($shop['password_hash']),
    ]);
    break;

/* ------------------------------------------------------------
 * SET PASSWORD (Step 2 of "I have a Shop ID")
 * ------------------------------------------------------------ */
case 'set-password':
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST required', 405);
    $shopId  = trim((string)($body['shop_id'] ?? ''));
    $pw      = (string)($body['password'] ?? '');
    $pw2     = (string)($body['password2'] ?? '');
    if (!valid_shop_id($shopId)) json_err('Invalid Shop ID', 422);
    if (!valid_password($pw))    json_err('Password must be at least 8 characters', 422);
    if ($pw !== $pw2)            json_err('Passwords do not match', 422);

    $shop = DB::one("SELECT * FROM shops WHERE shop_id = ? LIMIT 1", [$shopId]);
    if (!$shop) json_err('Shop ID not found', 404);
    if ($shop['status'] !== 'active') json_err('Shop is not active. Contact administrator.', 403);
    if (!$shop['email_verified_at']) json_err('Email not verified yet', 403);
    if (!empty($shop['password_hash'])) {
        json_err('Password already set for this shop. Use "Forgot password" to reset.', 409);
    }

    $hash = password_hash($pw, PASSWORD_BCRYPT, ['cost' => 12]);
    DB::update('shops', [
        'password_hash' => $hash,
        'updated_at'    => date('Y-m-d H:i:s'),
    ], 'id = :id', ['id' => $shop['id']]);
    audit((int)$shop['id'], $shop['email'], 'set_password', []);

    // Send welcome mail (best effort — failure is logged, not surfaced)
    try {
        $html = mail_welcome_shop($shop);
        send_mail($shop['email'], $shop['owner_name'], 'Your PADMA RMS account is ready', $html);
    } catch (Throwable $e) { error_log('welcome mail: ' . $e->getMessage()); }

    json_ok(['message' => 'Password set successfully. You can now log in.']);
    break;

/* ------------------------------------------------------------
 * FORGOT PASSWORD
 * ------------------------------------------------------------ */
case 'forgot':
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_err('POST required', 405);
    $shopId = trim((string)($body['shop_id'] ?? ''));
    $email  = strtolower(trim((string)($body['email'] ?? '')));
    if (!valid_shop_id($shopId) || !valid_email($email)) json_err('Invalid Shop ID or email', 422);
    if (!rate_limit_check('forgot:' . $shopId)) json_err('Too many attempts. Try later.', 429);

    $shop = DB::one("SELECT * FROM shops WHERE shop_id = ? AND LOWER(email) = ? LIMIT 1", [$shopId, $email]);
    if (!$shop) {
        // Return success anyway to prevent email enumeration
        json_ok(['message' => 'If the details match, a reset link has been sent to your email.']);
    }
    if ($shop['status'] !== 'active') json_err('Account is not active. Contact administrator.', 403);

    // Invalidate old reset tokens
    DB::run("UPDATE email_verifications SET used = 1 WHERE shop_ref = ? AND purpose = 'reset_password' AND used = 0", [(int)$shop['id']]);

    $token = generate_token(48);
    DB::insert('email_verifications', [
        'shop_ref'   => (int)$shop['id'],
        'token'      => $token,
        'purpose'    => 'reset_password',
        'expires_at' => date('Y-m-d H:i:s', time() + RESET_TTL_HOURS * 3600),
        'used'       => 0,
        'created_at' => date('Y-m-d H:i:s'),
    ]);
    $resetUrl = APP_URL . '/php/verify.php?reset=' . $token;
    send_mail($shop['email'], $shop['owner_name'], 'Reset your PADMA RMS password', mail_reset_password($shop, $resetUrl));

    json_ok(['message' => 'If the details match, a reset link has been sent to your email.']);
    break;

/* ------------------------------------------------------------
 * DEFAULT
 * ------------------------------------------------------------ */
default:
    json_err('Unknown action', 404);
}